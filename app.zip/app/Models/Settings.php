<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Settings extends Model
{
	protected $table = 'gs_settings';
	public $timestamps = false;
}
