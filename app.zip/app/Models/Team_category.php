<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Team_category extends Model
{
    protected $table = 'gs_team_category';
}
