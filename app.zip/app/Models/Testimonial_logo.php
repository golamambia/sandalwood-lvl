<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Testimonial_logo extends Model
{
    protected $table = 'testimonial_logo';
}
