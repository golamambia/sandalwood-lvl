<?php echo $__env->make('admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php
$form_array = unserialize(Form_Array);
?>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      Forms <button type="button" class="btn btn-primary" onclick="window.location.href='<?php echo e(url('/admin/forms/export/'.$form)); ?>'" title="Export Active User">Export</button>
    </h1>
    <ol class="breadcrumb">
      <li><a href=""><i class="fa fa-dashboard"></i> Home</a></li>
      <li class="active">Forms</li>
    </ol>
  </section>

  <!-- Main content -->
  <section class="content">

    <?php if($errors->any()): ?>   
    <div class="alert alert-danger alert-dismissible">
      <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
      <h4><i class="icon fa fa-ban"></i> Alert!</h4>
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php echo e($error); ?><br>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php endif; ?>

   <?php if(session()->has('delete_success')): ?>
   <div class="alert alert-success alert-dismissible">
    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
    <h4><i class="icon fa fa-ban"></i> Success</h4>
    Form Data has been deleted successfully.
  </div>
  <?php endif; ?>
   <?php if(session()->has('status_success')): ?>
   <div class="alert alert-success alert-dismissible">
    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
    <h4><i class="icon fa fa-ban"></i> Success</h4>
    Form Status is updated successfully.
  </div>
  <?php endif; ?>
   <?php if(session()->has('message')): ?>
   <div class="alert alert-success alert-dismissible">
    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
    <h4><i class="icon fa fa-ban"></i> Success</h4>
    <?php echo e(Session::get('message')); ?>

  </div>
  <?php endif; ?> 
  
  <div class="row">
    <div class="col-xs-12">
      <div class="box">
       <div class="box-header">
        <h3 class="box-title">&nbsp;</h3>
        <div class="box-tools">
          <form action="">
            <div class="col-sm-7">
              <div class="form-group clearfix">
                <select name="form" class="form-control" onchange="this.form.submit();">
                  <?php $__currentLoopData = $form_array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo $key; ?>" <?php if($key==$form): ?> selected <?php endif; ?>><?php echo $value; ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
            </div>
            <div class="col-sm-5">
            <div class="input-group input-group-sm" style="width: 150px;">

              <input type="text" name="search" class="form-control pull-right" placeholder="Search" value="<?php echo e($search); ?>">

              <div class="input-group-btn">
                <button type="submit" class="btn btn-default"><i class="fa fa-search"></i></button>
              </div>

            </div>
            </div>
          </form>
        </div>

      </div>
      <!-- /.box-header -->
      <div class="box-body table-responsive">

        <table id="example1" class="table table-bordered table-hover dataTable">
          <thead>
            <tr>
              <?php $__currentLoopData = $column_array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <th>
                <a href="<?php echo e($sorting_array[$key]['sorting_url']); ?>" class="<?php echo e($sorting_array[$key]['sorting_class']); ?>"><?php echo e($value); ?></a>
              </th>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <th>
                Action
              </th>
            </tr>
          </thead>
          <tbody>

          <?php if($lists->count() > 0): ?>
           <?php $__currentLoopData = $lists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

           <tr>
            <?php $__currentLoopData = $column_array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              
              <?php if($key=='first_name'): ?>
                <td><?php echo $list->$key.' '.$list->last_name; ?></td>
              <?php elseif($key=='created_at'): ?>              
                <td><?php echo date_convert($list->$key,3); ?></td>
              <?php elseif($key=='status'): ?>              
                <td><?php echo $user_status_array[$list->$key]; ?></td>
              <?php elseif($key=='last_login'): ?>
                <td><?php echo date_convert($list->$key, 4); ?></td>
              <?php else: ?>
                <td><?php echo e($list->$key); ?></td>
              <?php endif; ?>

              
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <td>
              <a href="<?php echo e(url('/admin/forms/view/'.$list->id)); ?>" title="View"><i class="fa fa-fw fa-eye"></i></a>
              <a href="<?php echo e(url('/admin/forms/delete/'.$list->id)); ?>" onclick="return confirm('Are you sure?');" title="Delete"><i class="fa fa-fw fa-close"></i></a>
            </td>

          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          <?php else: ?>

          <tr>
            <td colspan="<?php echo count($column_array)+1;?>" align="middle">No Data Found</td>
          </tr>

          <?php endif; ?>
        </tbody>

      </table>

      <?php echo e($lists->appends(request()->input())->links()); ?>


        </div>
        <!-- /.box-body -->
      </div>
      <!-- /.box -->

    </div>
    <!-- /.col -->
  </div>
  <!-- /.row -->
</section>
<!-- /.content -->

</div>
<!-- /.content-wrapper -->


<?php $__env->startSection('more-scripts'); ?>

<script type="text/javascript">


</script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php /**PATH G:\xampp\htdocs\dopadoxnw\resources\views/admin/form/index.blade.php ENDPATH**/ ?>