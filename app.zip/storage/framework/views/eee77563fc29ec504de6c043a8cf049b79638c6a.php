<?php
print_r($content)
?><?php /**PATH G:\xampp\htdocs\sandalwood\resources\views/mail.blade.php ENDPATH**/ ?>