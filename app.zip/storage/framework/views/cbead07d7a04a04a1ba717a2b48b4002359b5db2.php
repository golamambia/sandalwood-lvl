<?php
print_r($content)
?><?php /**PATH G:\xampp\htdocs\dopadoxnw\resources\views/mail.blade.php ENDPATH**/ ?>