<?php echo $__env->make('frontend.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__currentLoopData = $extra_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <?php if($val->type==1): ?>
<!------ banner area start -------->
<div class="subpagr_banner" style="background-image:url(<?php echo e(asset('frontend')); ?>/images/subbanner1.jpg);">
  <div class="container">
     <?php if($val->title): ?><h1><?php echo $val->title; ?></h1><?php endif; ?>
    
    <nav class="breadcrumb"> <a class="breadcrumb-item" href="<?php echo e(url('/')); ?>">home</a> <span class="breadcrumb-item active"><?php echo e($page->page_title); ?></span> </nav>
  </div>
</div>
<!------ banner area stop --------> 
 <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<!------ main area start -------->

<div class="mainarea p-80">
  <div class="employment_area">
    <div class="container">
      <div class="row">
      	 <?php $__currentLoopData = $extra_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <?php if($val->type==2 && $val->image && File::exists(public_path('uploads/'.$val->image))): ?>
        <div class="col-lg-6">
          <div class="employment_img_box"><img src="<?php echo e(asset('/uploads/'.$val->image)); ?>" alt="employment" title="" /></div>
        </div>
        <div class="col-lg-6">
          <div class="employment_contain_box">
            <h2><?php echo $val->title; ?></h2>
           <?php echo $val->body; ?>

          </div>
        </div>
<?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <div class="col-lg-12">
          <div class="employment_contain_box">
 <?php $__currentLoopData = $extra_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <?php if($val->type==3): ?>
            <h3><?php echo $val->title; ?></h3>
            <?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="row">
              <div class="col-lg-12">
                <ul>
<?php $__currentLoopData = $extra_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
 <?php if($val->type==4): ?>
                  <li><?php echo $val->title; ?></li>
                 
<?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
              </div>
              
            </div>
            <div class="w-100 mt-4">
            	 <?php $__currentLoopData = $extra_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <?php if($val->type==3 && $val->btn_text): ?>
              <a href="<?php echo e(url('/jobs-search')); ?>" class="btn-application"><?php echo $val->btn_text?$val->btn_text:'Employment Application'; ?></a>
              <?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!------ main area stop --------> 

<?php echo $__env->make('frontend.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp\htdocs\sandalwood\resources\views/frontend/pages/employment.blade.php ENDPATH**/ ?>