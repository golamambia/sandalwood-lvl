<?php echo $__env->make('admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      Add Testimonial
    </h1>
    <ol class="breadcrumb">
      <li><a href="<?php echo e(url('/admin/')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
      <li class="active">Add Testimonial</li>
    </ol>
  </section>

  
  <!-- Main content -->
  <section class="content">
    <div class="row">

      <div class="col-xm-12 col-sm-12 col-md-12">

        <div class="box box-primary">
          <div class="box-header with-border">
            <!--<h3 class="box-title">Quick Example</h3>-->
          </div>
          <!-- /.box-header -->
          <!-- form start -->
          <form role="form" action="<?php echo e(url('/admin/testimonial/add/')); ?>"  method="post" enctype="multipart/form-data" class="formvalidation">

            <?php echo csrf_field(); ?>

            <div class="box-body">

              <?php if($errors->any()): ?>   
              <div class="alert alert-danger alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <h4><i class="icon fa fa-ban"></i> Alert!</h4>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($error); ?><br>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
              <?php endif; ?>

              <?php if(session()->has('success')): ?>
              <div class="alert alert-success alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <h4><i class="icon fa fa-ban"></i> Success</h4>
                Testimonial has been added successfully.
              </div>
              <?php endif; ?>

              <div class="form-group clearfix">
                <label class="col-sm-2 control-label">Name</label>
                <div class="col-sm-10">
                  <input type="text" class="form-control" name="name" id="name" data-validation-engine="validate[required]" placeholder="Enter ..." value="<?php echo e(Request::old('name')); ?>">
                </div>
              </div>
              <div class="form-group clearfix">
                <label class="col-sm-2 control-label">Designation</label>
                <div class="col-sm-10">
                  <input type="text" class="form-control" name="designation" id="designation" placeholder="Enter ..." value="<?php echo e(Request::old('designation')); ?>">
                </div>
              </div>

              <div class="form-group clearfix">
                <label class="col-sm-2 control-label">Rank</label>
                <div class="col-sm-10">
                  <input type="text" class="form-control" name="rank" id="rank" data-validation-engine="validate[custom[number]]" placeholder="Enter ..." value="<?php echo e(Request::old('rank')); ?>">
                </div>
              </div>
              <!-- <div class="form-group clearfix">
                <label class="col-sm-2 control-label">Image</label>
                <div class="col-sm-10">
                  <input type="file" name="image" data-validation-engine="validate[,custom[validateMIME[image/jpeg|image/jpg|image/png|image/gif|image/svg]]]" >
                  Mime Type: jpeg,png,jpg,gif,svg, Max image upload size 2 Mb<br> 
                </div>
              </div> -->

              <div class="form-group clearfix">
                <label class="col-sm-2 control-label">Content</label>
                <div class="col-sm-10">
                  <textarea name="body" class="ckeditor" placeholder="Enter ..."><?php echo e(old('body')); ?></textarea>
                </div>
              </div>

              <div class="form-group clearfix">
                <label class="col-sm-2 control-label">Status</label>
                <div class="col-sm-10">
                  <select name="status" id="status" class="form-control">
                    <option value="1" <?php echo Request::old('status')=='1'?'selected':''; ?>>Active</option>
                    <option value="0" <?php echo Request::old('status')=='0'?'selected':''; ?>>Inactive</option>
                  </select>
                </div>
              </div>


            </div>
            <!-- /.box-body -->

            <div class="box-footer">
              <button type="submit" class="btn btn-primary" name="submit" value="Submit">Submit</button>
            </div>

          </form>
        </div>
        <!-- /.box -->

      </div>


    </div>
    <!-- /.row -->
  </section>
  <!-- /.content -->

</div>
<!-- /.content-wrapper -->

<?php echo $__env->make('admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /home/webtech7/public_html/project/globalization/resources/views/admin/testimonial/add.blade.php ENDPATH**/ ?>