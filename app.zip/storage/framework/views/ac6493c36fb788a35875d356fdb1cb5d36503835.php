<?php echo $__env->make('frontend.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__currentLoopData = $extra_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <?php if($val->type==1): ?>
<!------ banner area start -------->
<div class="subpagr_banner" style="background-image:url(<?php echo e(asset('/uploads/'.$val->image)); ?>);">
  <div class="container">
     <?php if($val->title): ?><h1><?php echo $val->title; ?></h1><?php endif; ?>
    
    <nav class="breadcrumb"> <a class="breadcrumb-item" href="<?php echo e(url('/')); ?>">home</a> <span class="breadcrumb-item active"><?php echo e($page->page_title); ?></span> </nav>
  </div>
</div>
<!------ banner area stop --------> 
 <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<!------ main area start -------->

<div class="mainarea p-80">
  <div class="contact_page">
    <div class="container">
      <div class="contact_pagetop mb-4">
        <h2 class="text-left">contact <span>us</span></h2>
        <div class="form-check-inline">
          <label class="form-check-label">
            <input type="radio" class="form-check-input" value="">
            Debit Card </label>
        </div>
        <div class="form-check-inline">
          <label class="form-check-label">
            <input type="radio" class="form-check-input" value="">
            Credit Card </label>
        </div>
        <div class="form-check-inline">
          <label class="form-check-label">
            <input type="radio" class="form-check-input" value="">
            Cash Pay </label>
        </div>
      </div>
      <div class="card_information">
             <form method="POST" action="<?php echo e(url('paymentform')); ?>" class="customvalidation">
           <?php echo csrf_field(); ?>
        <div class="row">
          <div class="col-lg-6">
            <div class="contact_pagetop">
              <h2 class="text-left">Card <span>Information</span></h2>
              <p class="text-left w-100">Include details of the card froms wich money will be debited</p>
              <img src="<?php echo e(asset('frontend')); ?>/images/card.png" alt="card" title="" /> </div>
          </div>

   
          <div class="col-lg-6">
            <div class="contact_pagetop">
               <?php $__currentLoopData = $extra_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <?php if($val->type==3): ?>
              <h2 class="text-left"><?php echo $val->title; ?></h2>
               <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             <?php if($errors->any()): ?>   
            <div class="alert alert-danger alert-dismissible">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            <h4><i class="icon fa fa-ban"></i> Alert!</h4>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo e($error); ?><br>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php endif; ?>
              <div class="row">
                <div class="col-lg-6">
                    <div class="form-group">
                      <input type="text" class="form-control" placeholder="First Name*" data-validation-engine="validate[required]" name="fname">
                    </div>
                  </div>
                  <div class="col-lg-6">
                    <div class="form-group">
                      <input type="text" class="form-control" placeholder="Last Name*" data-validation-engine="validate[required]" name="lname">
                    </div>
                  </div>
                  <div class="col-lg-6">
                    <div class="form-group">
                      <input type="email" class="form-control"  placeholder="Email*" data-validation-engine="validate[required]" name="email">
                    </div>
                  </div>
                  <div class="col-lg-6">
                    <div class="form-group">
                      <input type="text" class="form-control"placeholder="Phone*" data-validation-engine="validate[required]" name="phone">
                    </div>
                  </div>
                <div class="col-lg-6">
                    <div class="form-group">
                       <input type="text" class="form-control" placeholder="State*" data-validation-engine="validate[required]" name="state">
                      <!--  <select class="select form-control" name="estados" id="estados">
                          <option value="selecione" disabled selected>Selet State</option>
                      </select> -->
                    </div>
                  </div>
                  <div class="col-lg-6">
                    <div class="form-group">
                       <input type="text" class="form-control" placeholder="City*" data-validation-engine="validate[required]" name="city">
                      <!-- <select class="select form-control" name="cidades" id="cidades">
                         <option value="selecione" disabled selected>Selet city</option>
                      </select> -->
                    </div>
                  </div>
                  <div class="col-lg-12">
                    <div class="form-group">
                       <textarea class=" form-control" placeholder="Message" name="message"></textarea>
                    </div>
                  </div>
              </div>
            </div>
          </div>
          <div class="col-lg-12">
            <div class="w-100 text-center mt-4">
               <?php $__currentLoopData = $extra_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <?php if($val->type==2): ?>
              <button class="btn-application"><?php echo $val->btn_text?$val->btn_text:'Pay now'; ?></button>
               <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
          </div>


        </div>
</form>

      </div>
    </div>
  </div>
</div>
<!------ main area stop --------> 
<?php echo $__env->make('frontend.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp\htdocs\sandalwood\resources\views/frontend/pages/payment.blade.php ENDPATH**/ ?>