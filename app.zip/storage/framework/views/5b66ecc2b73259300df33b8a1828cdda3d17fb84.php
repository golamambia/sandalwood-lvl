<?php echo $__env->make('frontend.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php
$jobserach = get_fields_value_where('pages',"page_template=9",'id','desc');
?>
<!------ banner area start -------->

<?php $__currentLoopData = $jobserach; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php

$location_extra = get_fields_value_where('pages_extra',"page_id=".$val->id,'id','desc');
?>
<?php $__currentLoopData = $location_extra; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eval): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <?php if($eval->type==1): ?>
<!------ banner area start -------->
<div class="subpagr_banner" style="background-image:url(<?php echo e(asset('/uploads/'.$eval->image)); ?>);">
  <?php endif; ?>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <div class="container">
     <?php if($val->page_title): ?><h1><?php echo $val->page_title; ?></h1><?php endif; ?>
    
    <nav class="breadcrumb"> <a class="breadcrumb-item" href="<?php echo e(url('/')); ?>">home</a> <span class="breadcrumb-item active"><?php echo e($page->page_title); ?></span> </nav>
  </div>
</div>
<!------ banner area stop --------> 

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<!------ main area start -------->

<div class="mainarea p-80">
  <div class="employment_area">
    <div class="container">
       <div class="row">
         <div class="col-lg-8">
            <div class="career_box jobsearchdetails">
              <a href="/jobs-search" class="btn btn-link"> < Return to search results</a>
             
        <h3><?php echo $page->page_title; ?></h3>
         
            <?php echo $page->body; ?>

               
            </div>
        
           
         </div>

         <div class="col-lg-4">
           <div class="applynow_area contact_pageformbox">
             <h5>Apply jobs</h5>
            <?php if($errors->any()): ?>   
            <div class="alert alert-danger alert-dismissible">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            <h4><i class="icon fa fa-ban"></i> Alert!</h4>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo e($error); ?><br>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php endif; ?>
        <form method="POST" action="<?php echo e(url('careerform')); ?>" class="customvalidation" enctype="multipart/form-data">
           <?php echo csrf_field(); ?>
                <div class="form-group">
                  <label>Name</label>
                  <input type="text" class="form-control" name="name" placeholder="Name" data-validation-engine="validate[required]" value="<?php echo e(old('name')); ?>">
                </div>
                <div class="form-group">
                  <label>Email</label>
                  <input type="email" class="form-control" name="email" placeholder="email" data-validation-engine="validate[required]" value="<?php echo e(old('email')); ?>">
                </div>
                <div class="form-group">
                  <label>Phone no</label>
                  <input type="text" class="form-control numeric_input" name="phone" placeholder="Phone no" data-validation-engine="validate[required]" maxlength="10" value="<?php echo e(old('phone')); ?>">
                </div>
                <div class="form-group">
                  <label for="exampleFormControlFile1">Upload your cv</label>
                  <input type="file" name="resume" class="form-control-file form-control" id="exampleFormControlFile1" data-validation-engine="validate[required]">
                </div>
                <input type="submit" value="Apply Now" class="btn btn-primary" name="">
             </form>
           </div>
         </div>
       
    </div>
  </div>
</div>
</div>
<!------ main area stop --------> 


<?php echo $__env->make('frontend.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/webtech7/public_html/project/sandalwood/resources/views/frontend/pages/jobs_search_details.blade.php ENDPATH**/ ?>