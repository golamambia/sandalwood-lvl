<?php echo $__env->make('frontend.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php $__currentLoopData = $extra_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <?php if($val->type==1): ?>
<!------- inner banner area start ------->
<section class="inner_banner_area" style="background-image: url(<?php echo e(asset('/uploads/'.$val->image)); ?>);">
  <div class="container">
    <div class="inner_banner_contain">
      <?php if($val->title): ?><h1><?php echo $val->title; ?></h1><?php endif; ?>
      <?php echo $val->body; ?>

      <?php if($val->btn_url): ?><a href="<?php echo $val->btn_url; ?>" class="btn btn-custom mt-4"><?php echo $val->btn_text?$val->btn_text:'contact Us'; ?></a><?php endif; ?>
    </div>
  </div>
</section>
  <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<div class="mainbox p-8">
<?php $__currentLoopData = $extra_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <?php if($val->type==2 && ($val->title || $val->body)): ?>
  <div class="innerabout_us">
    <div class="container">
      <div class="row">
        <div class="col-lg-6 col-md-6">
          <div class="innerabout_thumble pt-4 pr-4">
            <?php if($val->image && File::exists(public_path('uploads/'.$val->image)) ): ?><img src="<?php echo e(asset('/uploads/'.$val->image)); ?>"> <?php endif; ?>
          </div>
        </div>
        <div class="col-lg-6 col-md-6">
          <div class="innerabout_contantbox">
            <?php if($val->title || $val->sub_title): ?><h3><?php echo $val->title; ?> <strong><?php echo $val->sub_title; ?></strong></h3><?php endif; ?>
            <?php echo $val->body; ?>

          </div>
        </div>
      </div>
    </div>
  </div>
  <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  <div class="ourglobalreach_area p-8">
    <div class="container">
      <div class="text-center">
<?php $__currentLoopData = $extra_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <?php if($val->type==3): ?>
        <?php if($val->title || $val->sub_title): ?><h3><?php echo $val->title; ?> <strong><?php echo $val->sub_title; ?></strong></h3><?php endif; ?>
            <?php echo $val->body; ?>

  <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <div class="row">
<?php $__currentLoopData = $extra_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <?php if($val->type==4 && ($val->title || $val->body)): ?>
          <div class="col-lg-4 col-md-4 d-flex align-content-stretch">
            <div class="serviceslist_box">
             <div class="services_icon" style="background-image: url(<?php echo e(asset('/uploads/'.$val->image)); ?>);"></div>
              <?php if($val->title): ?><h4><?php echo $val->title; ?></h4><?php endif; ?>
              <?php echo $val->body; ?>

              <?php if($val->btn_url): ?><a href="<?php echo $val->btn_url; ?>" class="btn btn-custom"><?php echo $val->btn_text?$val->btn_text:'read more'; ?></a><?php endif; ?>
             <div class="shap">
              <img src="<?php echo e(asset('/frontend/images/workaffterbg.png')); ?>" alt="">
             </div>
             </div>
          </div>
  <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       </div>
     </div>
   </div>
 </div>

<div class="Whatwedo_area opportunityarea p-8 pt-0">
   <div class="container">
<?php $__currentLoopData = $extra_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <?php if($val->type==5 && ($val->title || $val->body)): ?>
    <div class="Whatwedo_box row">
     <div class="col-lg-6 col-md-6 Whatwedoimg d-flex flex-wrap align-content-stretch">
       <div class="Whatwedo_thumble d-flex">
         <?php if($val->image && File::exists(public_path('uploads/'.$val->image)) ): ?><img src="<?php echo e(asset('/uploads/'.$val->image)); ?>"> <?php endif; ?>
       </div>
     </div>
     <div class="col-lg-6 col-md-6 Whatwedocontent d-flex flex-wrap align-content-stretch align-items-center">
       <div class="Whatwedo_textbox">
        <?php if($val->title || $val->sub_title): ?><h3><?php echo $val->title; ?> <strong><?php echo $val->sub_title; ?></strong></h3><?php endif; ?>
        <?php echo $val->body; ?>

      </div>
    </div>
  </div>
  <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

     </div>
   </div>


<?php $__currentLoopData = $extra_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <?php if($val->type==6 && ($val->title || $val->body)): ?>
<div class="Workwithus_area inneradd">
  <div class="container">
    <div class="Workwithus_box" style="background-image: url(<?php echo e(asset('/uploads/'.$val->image)); ?>);">
      <div class="Workwithus_innerbox pt-4 pb-4">
        
        <?php if($val->title || $val->sub_title): ?><h4><?php echo $val->title; ?> <strong><?php echo $val->sub_title; ?></strong></h4><?php endif; ?>
        <div class="custom_div p-0"><?php echo $val->body; ?></div>
           
      </div>
    </div>
  </div>
</div>
  <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


</div>






<?php $__env->startSection('more-scripts'); ?>

<script type="text/javascript">
$(window).ready (function () {
});
</script>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('frontend.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/webtech7/public_html/project/globalization/resources/views/frontend/pages/service.blade.php ENDPATH**/ ?>