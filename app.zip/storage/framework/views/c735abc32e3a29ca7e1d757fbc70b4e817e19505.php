<?php echo $__env->make('frontend.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<!------- inner banner area start ------->
   <?php $__currentLoopData = $extra_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($val->type==1 && $val->image && File::exists(public_path('uploads/'.$val->image))): ?>
   
      <div class="contact-banner " style="background: url(<?php echo e(asset('/uploads/'.$val->image)); ?>) no-repeat center top; ">
        <div class="container ">
            <div class="txt wow fadeInRight " data-wow-deuration="2s " data-wow-delay=".2s ">
                 <?php if($val->title): ?><h1><?php echo $val->title; ?></h1><?php endif; ?>
                <?php echo $val->body; ?>

            </div>
        </div>
            <div class="txt-hldr"><h2>CONTACT US</h2>
            <p><marquee width="100%" direction="left" height="100px">reach us by email- ouremailid@gmil.com, call us at +91 1234567890, ﬁnd us at social media- @faceb  reach us by email- ouremailid@gmil.com, call us at +91 1234567890, ﬁnd us at social media- @faceb  reach us by email- ouremailid@gmil.com, call us at +91 1234567890, ﬁnd us at social media- @faceb</marquee></p>
        </div>
    </div>
    <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
<div class="contact">
        <div class="container">
          <?php $__currentLoopData = $extra_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

      <?php if($val->type==3): ?>
           <?php if($val->title): ?>
            <h3><?php echo $val->title; ?></h3> <?php endif; ?>
            <?php if($val->body): ?> <?php echo $val->body; ?><?php endif; ?>
             <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
   
    <div class="hm-contact ">
        <div class="container ">
            <div class="hldr wow fadeInUp " data-wow-deuration="2s " data-wow-delay=".2s ">
                 <?php $__currentLoopData = $extra_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

      <?php if($val->type==3 && $val->image && File::exists(public_path('uploads/'.$val->image))): ?>
                <div class="hm-contact-logo ">
                    <img src="<?php echo e(asset('/uploads/'.$val->image)); ?> " alt=" ">
                </div>
                 <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php if($errors->any()): ?>   
            <div class="alert alert-danger alert-dismissible">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            <h4><i class="icon fa fa-ban"></i> Alert!</h4>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo e($error); ?><br>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php endif; ?>
        <form method="POST" action="<?php echo e(url('contact')); ?>" class="customvalidation">
                        <?php echo csrf_field(); ?>
                    <div class="form-group">
                       <label>Full name</label>
                            <input type="text" class="form-control" placeholder="Full name*" data-validation-engine="validate[required]" name="name">
                        </div>
                        <div class="form-group">
                           <label>Email Id</label>
                            <input type="text" class="form-control" placeholder="Business Email*" data-validation-engine="validate[required,custom[email]]" name="email">
                        </div>
                    <div class="form-group ">
                        <label>Type your Message</label>
                        <textarea class="form-control " placeholder="Message"></textarea>
                    </div>
                    <div class="form-group ">
                        <label class="check "><input type="checkbox"><span class="checkmark "></span> Need NDA?</label>
                    </div>
                    <div class="form-group "><input type="submit" value="Send "></div>
                </form>
            </div>
        </div>
    </div>




<?php echo $__env->make('frontend.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp\htdocs\globalization\resources\views/frontend/pages/contact_us.blade.php ENDPATH**/ ?>