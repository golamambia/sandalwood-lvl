<?php echo $__env->make('frontend.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="inner-page">
        <div class="team-page">
            <div class="container">
                <h1>MEET<br>
                    OUR TEAM</h1>
                    <ul class="team row">
                        <li class="col-lg-3 col-md-3">
                            <div class="hldrr"><div class="img-hldr"><img src="<?php echo e(asset('frontend')); ?>/img/banner.png" alt=""></div>
                            <h3>Lorem ipsum</h3>
                            <p>Lorem ipsum</p></div>
                        </li>
                        <li class="col-lg-3 col-md-3">
                            <div class="hldrr"><div class="img-hldr"><img src="<?php echo e(asset('frontend')); ?>/img/banner.png" alt=""></div>
                            <h3>Lorem ipsum</h3>
                            <p>Lorem ipsum</p></div>
                        </li>
                        <li class="col-lg-3 col-md-3">
                            <div class="hldrr"><div class="img-hldr"><img src="<?php echo e(asset('frontend')); ?>/img/banner.png" alt=""></div>
                            <h3>Lorem ipsum</h3>
                            <p>Lorem ipsum</p></div>
                        </li>
                        <li class="col-lg-3 col-md-3">
                            <div class="hldrr"><div class="img-hldr"><img src="<?php echo e(asset('frontend')); ?>/img/banner.png" alt=""></div>
                            <h3>Lorem ipsum</h3>
                            <p>Lorem ipsum</p></div>
                        </li>
                    </ul>
            </div>
        </div>
        <div class="team-list">
            <h2><span>DEVELOPER</span></h2>
            <div class="container">
                <ul>
                    <li>
                        <div class="img-hldr"><img src="<?php echo e(asset('frontend')); ?>/img/banner.png" alt=""></div>
                        <h4>Full Name</h4>
                        <p>DESIGNATION/ SKILL SET</p>
                    </li>
                    <li>
                        <div class="img-hldr"><img src="<?php echo e(asset('frontend')); ?>/img/banner.png" alt=""></div>
                        <h4>Full Name</h4>
                        <p>DESIGNATION/ SKILL SET</p>
                    </li>
                    <li>
                        <div class="img-hldr"><img src="<?php echo e(asset('frontend')); ?>/img/banner.png" alt=""></div>
                        <h4>Full Name</h4>
                        <p>DESIGNATION/ SKILL SET</p>
                    </li>
                    <li>
                        <div class="img-hldr"><img src="<?php echo e(asset('frontend')); ?>/img/banner.png" alt=""></div>
                        <h4>Full Name</h4>
                        <p>DESIGNATION/ SKILL SET</p>
                    </li>
                </ul>
            </div>
        </div>
        <div class="team-list">
            <h2><span>UI / UX</span></h2>
            <div class="container">
                <ul>
                    <li>
                        <div class="img-hldr"><img src="<?php echo e(asset('frontend')); ?>/img/banner.png" alt=""></div>
                        <h4>Full Name</h4>
                        <p>DESIGNATION/ SKILL SET</p>
                    </li>
                    <li>
                        <div class="img-hldr"><img src="<?php echo e(asset('frontend')); ?>/img/banner.png" alt=""></div>
                        <h4>Full Name</h4>
                        <p>DESIGNATION/ SKILL SET</p>
                    </li>
                    <li>
                        <div class="img-hldr"><img src="<?php echo e(asset('frontend')); ?>/img/banner.png" alt=""></div>
                        <h4>Full Name</h4>
                        <p>DESIGNATION/ SKILL SET</p>
                    </li>
                    <li>
                        <div class="img-hldr"><img src="<?php echo e(asset('frontend')); ?>/img/banner.png" alt=""></div>
                        <h4>Full Name</h4>
                        <p>DESIGNATION/ SKILL SET</p>
                    </li>
                    <li>
                        <div class="img-hldr"><img src="<?php echo e(asset('frontend')); ?>/img/banner.png" alt=""></div>
                        <h4>Full Name</h4>
                        <p>DESIGNATION/ SKILL SET</p>
                    </li>
                    <li>
                        <div class="img-hldr"><img src="<?php echo e(asset('frontend')); ?>/img/banner.png" alt=""></div>
                        <h4>Full Name</h4>
                        <p>DESIGNATION/ SKILL SET</p>
                    </li>
                    <li>
                        <div class="img-hldr"><img src="<?php echo e(asset('frontend')); ?>/img/banner.png" alt=""></div>
                        <h4>Full Name</h4>
                        <p>DESIGNATION/ SKILL SET</p>
                    </li>
                    <li>
                        <div class="img-hldr"><img src="<?php echo e(asset('frontend')); ?>/img/banner.png" alt=""></div>
                        <h4>Full Name</h4>
                        <p>DESIGNATION/ SKILL SET</p>
                    </li>
                </ul>
            </div>
        </div>
        <div class="team-list">
            <h2><span>GRAPHIC DESIGNER</span></h2>
            <div class="container">
                <ul>
                    <li>
                        <div class="img-hldr"><img src="<?php echo e(asset('frontend')); ?>/img/banner.png" alt=""></div>
                        <h4>Full Name</h4>
                        <p>DESIGNATION/ SKILL SET</p>
                    </li>
                    <li>
                        <div class="img-hldr"><img src="<?php echo e(asset('frontend')); ?>/img/banner.png" alt=""></div>
                        <h4>Full Name</h4>
                        <p>DESIGNATION/ SKILL SET</p>
                    </li>
                </ul>
            </div>
        </div>
        <div class="team-list">
            <h2><span>ANIMATOR</span></h2>
            <div class="container">
                <ul>
                    <li>
                        <div class="img-hldr"><img src="<?php echo e(asset('frontend')); ?>/img/banner.png" alt=""></div>
                        <h4>Full Name</h4>
                        <p>DESIGNATION/ SKILL SET</p>
                    </li>
                    <li>
                        <div class="img-hldr"><img src="<?php echo e(asset('frontend')); ?>/img/banner.png" alt=""></div>
                        <h4>Full Name</h4>
                        <p>DESIGNATION/ SKILL SET</p>
                    </li>
                </ul>
            </div>
        </div>
        <div class="team-list">
            <h2><span>CONTENT WRITER</span></h2>
            <div class="container">
                <ul>
                    <li>
                        <div class="img-hldr"><img src="<?php echo e(asset('frontend')); ?>/img/banner.png" alt=""></div>
                        <h4>Full Name</h4>
                        <p>DESIGNATION/ SKILL SET</p>
                    </li>
                    <li>
                        <div class="img-hldr"><img src="<?php echo e(asset('frontend')); ?>/img/banner.png" alt=""></div>
                        <h4>Full Name</h4>
                        <p>DESIGNATION/ SKILL SET</p>
                    </li>
                </ul>
            </div>
        </div>
        <div class="team-list">
            <h2><span>TESTER</span></h2>
            <div class="container">
                <ul>
                    <li>
                        <div class="img-hldr"><img src="<?php echo e(asset('frontend')); ?>/img/banner.png" alt=""></div>
                        <h4>Full Name</h4>
                        <p>DESIGNATION/ SKILL SET</p>
                    </li>
                    <li>
                        <div class="img-hldr"><img src="<?php echo e(asset('frontend')); ?>/img/banner.png" alt=""></div>
                        <h4>Full Name</h4>
                        <p>DESIGNATION/ SKILL SET</p>
                    </li>
                </ul>
            </div>
        </div>
        <div class="team-list">
            <h2><span>DATA ENTRY EXECUIVE</span></h2>
            <div class="container">
                <ul>
                    <li>
                        <div class="img-hldr"><img src="<?php echo e(asset('frontend')); ?>/img/banner.png" alt=""></div>
                        <h4>Full Name</h4>
                        <p>DESIGNATION/ SKILL SET</p>
                    </li>
                    <li>
                        <div class="img-hldr"><img src="<?php echo e(asset('frontend')); ?>/img/banner.png" alt=""></div>
                        <h4>Full Name</h4>
                        <p>DESIGNATION/ SKILL SET</p>
                    </li>
                </ul>
            </div>
        </div>
    </div>

<?php echo $__env->make('frontend.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp\htdocs\dopadoxnw\resources\views/frontend/pages/team.blade.php ENDPATH**/ ?>