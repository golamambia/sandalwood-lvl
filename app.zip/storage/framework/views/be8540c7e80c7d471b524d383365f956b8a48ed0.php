<?php echo $__env->make('frontend.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php
$jobsearch = get_fields_value_where('pages',"posttype='jobsearch'",'id','desc');
?>
<!------ banner area start -------->

<?php $__currentLoopData = $extra_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <?php if($val->type==1): ?>
<!------ banner area start -------->
<div class="subpagr_banner" style="background-image:url(<?php echo e(asset('/uploads/'.$val->image)); ?>);">
  <div class="container">
     <?php if($val->title): ?><h1><?php echo $val->title; ?></h1><?php endif; ?>
    
    <nav class="breadcrumb"> <a class="breadcrumb-item" href="<?php echo e(url('/')); ?>">home</a> <span class="breadcrumb-item active"><?php echo e($page->page_title); ?></span> </nav>
  </div>
</div>
<!------ banner area stop --------> 
 <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<!------ main area start -------->

<div class="mainarea p-80">
  <div class="employment_area">
    <div class="container">
       <div class="row">
         <div class="col-lg-12">
            <div class="row">
              <?php if($jobsearch->count() > 0): ?>
 <?php $__currentLoopData = $jobsearch; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="col-lg-6 d-flex align-content-stretch">
            <div class="career_box">
              <a href="<?php echo e(url('/')); ?>/<?php echo $val->slug; ?>">
              <h3><?php echo $val->page_title; ?></h3>
              <h4><?php echo $val->job_type; ?></h4>
              <p><strong>Location :</strong> <?php echo $val->location; ?></p>
              <p><strong>Job Description :</strong> <?php echo e(substr(strip_tags($val->body),0,150)); ?>...</p>
              
            </a>
            </div>
          </div>


<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         <?php endif; ?>
          </div>
         </div>

       
    </div>
  </div>
</div>
</div>
<!------ main area stop --------> 


<?php echo $__env->make('frontend.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp\htdocs\sandalwood\resources\views/frontend/pages/jobs_search.blade.php ENDPATH**/ ?>