<?php echo $__env->make('frontend.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- <section class="inner_banner_area" style="background-image: url(<?php echo $page->bannerimage && File::exists(public_path('uploads/'.$page->bannerimage))?asset('/uploads/'.$page->bannerimage):asset('/frontend/images/inner-bg.jpg'); ?>);">
  <div class="container">
    <div class="inner_banner_contain">
      <h1><strong><?php echo $page->page_title; ?></strong> </h1>
    </div>
  </div>
</section>  -->
<?php $__currentLoopData = $extra_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <?php if($val->type==1): ?>
<!------- inner banner area start ------->
<section class="inner_banner_area" style="background-image: url(<?php echo e(asset('/uploads/'.$val->image)); ?>);">
  <div class="container">
    <div class="inner_banner_contain">
      <?php if($val->title): ?><h1><?php echo $val->title; ?></h1><?php endif; ?>
      <?php echo $val->body; ?>

      <?php if($val->btn_url): ?><a href="<?php echo $val->btn_url; ?>" class="btn btn-custom mt-4"><?php echo $val->btn_text?$val->btn_text:'contact Us'; ?></a><?php endif; ?>
    </div>
  </div>
</section>
  <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<div class="mainbox p-8">
  <?php if($page->body): ?>
  <div class="about_single">
    <div class="container">
      <div class="text-center">
        <?php echo $page->body; ?>

      </div>
    </div>
  </div>
  <?php endif; ?>

  <?php $__currentLoopData = $extra_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <?php if($val->type!=1): ?>
  <div class="about_single">
    <div class="container">
      <div class="text-center">
        <?php if($val->title): ?><h3><?php echo $val->title; ?></h3><?php endif; ?>
        <?php echo $val->body; ?>

      </div>
    </div>
  </div>
  <?php endif; ?>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<?php echo $__env->make('frontend.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp\htdocs\sandalwood\resources\views/frontend/pages/pages.blade.php ENDPATH**/ ?>