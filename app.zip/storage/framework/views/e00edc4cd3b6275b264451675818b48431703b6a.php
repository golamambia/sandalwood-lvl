<?php echo $__env->make('frontend.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php
$testimonials = get_fields_value_where('gs_testimonial',"status='1'",'rank','asc');
?>


    <?php $__currentLoopData = $extra_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($val->type==1 && $val->image && File::exists(public_path('uploads/'.$val->image))): ?>
    <div class=" banner " style="background: url(<?php echo e(asset('/uploads/'.$val->image)); ?>) no-repeat center top; ">
        <div class="container ">
            <div class="banner-txt wow fadeInRight " data-wow-deuration="2s " data-wow-delay=".2s ">
               
                <?php if($val->title): ?><h1><?php echo $val->title; ?></h1><?php endif; ?>
                <?php echo $val->body; ?>

                <?php if($val->btn_url): ?><a href="<?php echo $val->btn_url; ?>" class="btn btn-primary"><?php echo $val->btn_text?$val->btn_text:'contact Us'; ?></a><?php endif; ?>
            </div>
           
        </div>
    </div>
    <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    <div class="hm-trasted ">
        <div class="container ">

        <?php $__currentLoopData = $extra_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

      <?php if($val->type==2 && $val->title): ?>
            <h2 class=" wow zoomIn " data-wow-deuration="2s " data-wow-delay=".2s "><?php echo $val->title; ?></h2>
    <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="owl-carousel company-logo owl-theme wow fadeInUp " data-wow-deuration="2s " data-wow-delay=".2s ">

        <?php $__currentLoopData = $extra_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

      <?php if($val->type==3 && $val->image && File::exists(public_path('uploads/'.$val->image))): ?>
                <div class="item ">
                    <div class="img-hldr ">
                        <img src="<?php echo e(asset('/uploads/'.$val->image)); ?>" alt=" ">
                    </div>
                </div>
    <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>


    <div class="hm-services ">
        <div class="container ">

        <?php $__currentLoopData = $extra_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

      <?php if($val->type==4): ?>
            <?php if($val->title): ?><h2 class=" wow zoomIn " data-wow-deuration="2s " data-wow-delay=".2s "><?php echo $val->title; ?></h2><?php endif; ?>
            <div class=" wow zoomIn " data-wow-deuration="2s " data-wow-delay=".2s "><?php echo $val->body; ?></div>
    <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <ul class="service-li wow fadeInUp " data-wow-deuration="2s " data-wow-delay=".2s ">
        <?php $__currentLoopData = $extra_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

      <?php if($val->type==5): ?>
                <li>
                    <a href="# ">
                        <div class="icn "><img src="img/custom_software.png " alt=" "> </div>
                        <h4>Custom Software</h4>
                        <?php if($val->title): ?><h4><?php echo $val->title; ?></h4><?php endif; ?>
                        <?php echo $val->body; ?>

                    </a>
                </li>
    <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        <?php $__currentLoopData = $extra_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

      <?php if($val->type==6 && $val->btn_url): ?>
            <div class="clear-fix "></div> <a href="<?php echo $val->btn_url; ?>" id="loadMore"><?php echo $val->btn_text; ?></a>
    <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>


<?php $__env->startSection('more-scripts'); ?>

<script>
$(document).ready(function() { 
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php /**PATH G:\xampp\htdocs\globalization\resources\views/frontend/home.blade.php ENDPATH**/ ?>