<?php echo $__env->make('admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php
$form_array = unserialize(Form_Array);
?>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      View <?php echo e($form_array[$list->type]); ?> Data
    </h1>
    <ol class="breadcrumb">
      <li><a href=""><i class="fa fa-dashboard"></i> Home</a></li>
      <li class="active">View Form Data</li>
    </ol>
  </section>

  
  <!-- Main content -->
  <section class="content">
    <div class="row">

      <div class="col-xm-12 col-sm-12 col-md-12">

        <div class="box box-primary">
          <div class="box-header with-border">
            <!--<h3 class="box-title">Quick Example</h3>-->
          </div>
          <!-- /.box-header -->

            <div class="box-body">

              <?php if($errors->any()): ?>   
              <div class="alert alert-danger alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <h4><i class="icon fa fa-ban"></i> Alert!</h4>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($error); ?><br>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
              <?php endif; ?>

              <?php if(session()->has('success')): ?>
              <div class="alert alert-success alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <h4><i class="icon fa fa-ban"></i> Success</h4>
                Form has been updated successfully.
              </div>
              <?php endif; ?>

              <div class="row">
                <div class="col-sm-12"> 

                  <?php if($list->type=='1' || $list->type=='3'): ?>
                  <div class="form-group clearfix">
                    <label class="col-sm-3 control-label">Name</label>
                    <div class="col-sm-6"><?php echo e($list->name); ?> </div>
                  </div>
                
                  <?php else: ?>
                    <div class="form-group clearfix">
                    <label class="col-sm-3 control-label">First Name</label>
                    <div class="col-sm-6"><?php echo e($list->fname); ?> </div>
                  </div>
                  <div class="form-group clearfix">
                    <label class="col-sm-3 control-label">Last Name</label>
                    <div class="col-sm-6"><?php echo e($list->lname); ?> </div>
                  </div>
                  <?php endif; ?>

                  <div class="form-group clearfix">
                    <label class="col-sm-3 control-label">Email</label>
                    <div class="col-sm-6"><?php echo e($list->email); ?> </div>
                  </div>
                   <div class="form-group clearfix">
                    <label class="col-sm-3 control-label">Phone Number</label>
                    <div class="col-sm-6"><?php echo e($list->phone); ?> </div>
                  </div>
                   <?php if($list->type=='0'): ?>
                   <div class="form-group clearfix">
                    <label class="col-sm-3 control-label">Address</label>
                    <div class="col-sm-6"><?php echo e($list->address); ?> </div>
                  </div>
                  <div class="form-group clearfix">
                    <label class="col-sm-3 control-label">Zip code</label>
                    <div class="col-sm-6"><?php echo e($list->zip); ?> </div>
                  </div>
                  <div class="form-group clearfix">
                    <label class="col-sm-3 control-label">State</label>
                    <div class="col-sm-6"><?php echo e($list->state); ?> </div>
                  </div>
                  <div class="form-group clearfix">
                    <label class="col-sm-3 control-label">City</label>
                    <div class="col-sm-6"><?php echo e($list->city); ?> </div>
                  </div>
                  <div class="form-group clearfix">
                    <label class="col-sm-3 control-label">Reason for contact</label>
                    <div class="col-sm-6"><?php echo e($list->reason); ?> </div>
                  </div>
                  <div class="form-group clearfix">
                    <label class="col-sm-3 control-label">Message</label>
                    <div class="col-sm-6"><?php echo e($list->message); ?> </div>
                  </div>

                  <?php elseif($list->type=='2'): ?>

                   <div class="form-group clearfix">
                    <label class="col-sm-3 control-label">Zip code</label>
                    <div class="col-sm-6"><?php echo e($list->zip); ?> </div>
                  </div>
                  <div class="form-group clearfix">
                    <label class="col-sm-3 control-label">State</label>
                    <div class="col-sm-6"><?php echo e($list->state); ?> </div>
                  </div>
                  <div class="form-group clearfix">
                    <label class="col-sm-3 control-label">City</label>
                    <div class="col-sm-6"><?php echo e($list->city); ?> </div>
                  </div>
                   <?php elseif($list->type=='3'): ?>
                     <?php if($list->resume && File::exists(public_path('uploads/'.$list->resume))): ?>
                  <div class="form-group clearfix">
                    <label class="col-sm-3 control-label">Resume</label>
                    <div class="col-sm-6"><a href="<?php echo e(asset('/uploads/'.$list->resume)); ?>" download>Download</a> </div>
                  </div>
                  <?php endif; ?>
                   <?php endif; ?>
                 
                  <div class="form-group clearfix">
                    <label class="col-sm-3 control-label">Created</label>
                    <div class="col-sm-6"><?php echo date_convert($list->created_at,3); ?> </div>
                  </div>
                  
                </div>                
              </div>


              </div>
              <!-- /.box-body -->

              <div class="box-footer">
                <button type="button" class="btn btn-primary" onclick="window.location.href='<?php echo e(url('/admin/forms')); ?>'" >Back</button>
              </div>

            </form>
          </div>
          <!-- /.box -->

        </div>


      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->

  </div>
  <!-- /.content-wrapper -->


  <?php echo $__env->make('admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH G:\xampp\htdocs\sandalwood\resources\views/admin/form/view.blade.php ENDPATH**/ ?>