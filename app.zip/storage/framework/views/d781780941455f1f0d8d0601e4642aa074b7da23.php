<?php echo $__env->make('frontend.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__currentLoopData = $extra_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <?php if($val->type==1): ?>
<!------ banner area start -------->
<div class="subpagr_banner" style="background-image:url(<?php echo e(asset('frontend')); ?>/images/subbanner1.jpg);">
  <div class="container">
     <?php if($val->title): ?><h1><?php echo $val->title; ?></h1><?php endif; ?>
    
    <nav class="breadcrumb"> <a class="breadcrumb-item" href="<?php echo e(url('/')); ?>">home</a> <span class="breadcrumb-item active"><?php echo e($page->page_title); ?></span> </nav>
  </div>
</div>
<!------ banner area stop --------> 
 <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<!------ main area start -------->

<div class="mainarea p-80">
  <div class="contact_page">
    <div class="container">
       <?php $__currentLoopData = $extra_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <?php if($val->type==2 && $val->image && File::exists(public_path('uploads/'.$val->image))): ?>
      <div class="row service_area">
        <div class="col-lg-6 col-md-6 service_box_img">
          <div class="service_img_box mb-5"> <img src="<?php echo e(asset('/uploads/'.$val->image)); ?>" alt="service" title="" /> </div>
        </div>
        <div class="col-lg-6 col-md-6 service_box">
          <div class="contact_pagetop mb-4 pt-5 pl-5">
            <h2 class="text-left"><?php echo $val->title; ?></h2>
            <?php echo $val->body; ?>

            
             <?php if($val->btn_text): ?><a href="<?php echo $val->btn_url; ?>" class="more"><?php echo $val->btn_text?$val->btn_text:'read more'; ?></a><?php endif; ?>
          </div>
        </div>
      </div>
      <?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

   
      


    </div>
  </div>
</div>
<!------ main area stop --------> 
   

<?php echo $__env->make('frontend.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp\htdocs\sandalwood\resources\views/frontend/pages/where_to_begin.blade.php ENDPATH**/ ?>