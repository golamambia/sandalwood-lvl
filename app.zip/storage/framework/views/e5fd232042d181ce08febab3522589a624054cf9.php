<?php echo $__env->make('frontend.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

 <!------- inner banner area start ------->
    <?php $__currentLoopData = $extra_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($val->type==1): ?>

<section class="inner_banner_area" style="background-image: url(<?php echo e(asset('/uploads/'.$val->image)); ?>);">
        <div class="container">
            <div class="inner_banner_contain">
                <?php if($val->title): ?><h1><?php echo $val->title; ?></h1><?php endif; ?>
                <?php echo $val->body; ?>

                <?php if($val->btn_url): ?><a href="<?php echo $val->btn_url; ?>" class="btn btn-custom mt-4"><?php echo $val->btn_text?$val->btn_text:'contact Us'; ?></a><?php endif; ?>
            </div>
        </div>
 </section>
    <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<div class="mainbox p-8">
<?php $__currentLoopData = $extra_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <?php if($val->type==2): ?>
  <div class="innerabout_us">
    <div class="container">
      <div class="row">
        <div class="col-lg-6 col-md-6">
          <div class="innerabout_thumble">
          	<?php if($val->image && File::exists(public_path('uploads/'.$val->image)) ): ?>
            <img src="<?php echo e(asset('/uploads/'.$val->image)); ?>" alt=""><?php endif; ?>
          </div>
        </div>
        <div class="col-lg-6 col-md-6">
          <div class="innerabout_contantbox">
            <h3><?php echo $val->title; ?> <strong><?php echo $val->sub_title; ?></strong></h3>
            <?php echo $val->body; ?>

          </div>
        </div>
      </div>
    </div>
  </div>
 <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


  <div class="ourglobalreach_area p-8">
    <div class="container">
      <div class="text-center">
      	<?php $__currentLoopData = $extra_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

      <?php if($val->type==3): ?>
        <h3><?php echo $val->title; ?> <strong><?php echo $val->sub_title; ?></strong></h3>
        <?php echo $val->body; ?>

        <?php endif; ?>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <div class="row">
    		<?php $__currentLoopData = $extra_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      		<?php if($val->type==4): ?>
          <div class="col-lg-4 col-md-4 d-flex align-content-stretch">
            <div class="serviceslist_box">
            	<?php if($val->image && File::exists(public_path('uploads/'.$val->image)) ): ?>
             <div class="services_icon" style="background-image: url(<?php echo e(asset('/uploads/'.$val->image)); ?>);"></div><?php endif; ?>
            <?php if($val->title): ?><h4><?php echo $val->title; ?></h4><?php endif; ?>
				<?php echo $val->body; ?>

				<div class="shap">
              <img src="<?php echo e(asset('/frontend/images/workaffterbg.png')); ?>" alt="">
            </div>
             </div>
          </div>
	<?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
      </div>
    </div>
  </div>

<div class="Whatwedo_area opportunityarea p-8 pt-0">
 <div class="container">

    		<?php $__currentLoopData = $extra_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      		<?php if($val->type==5): ?>
    <div class="Whatwedo_box row">
     <div class="col-lg-6 col-md-6 Whatwedoimg d-flex flex-wrap align-content-stretch">
         <div class="Whatwedo_thumble d-flex">
           <?php if($val->image && File::exists(public_path('uploads/'.$val->image)) ): ?>
            <img src="<?php echo e(asset('/uploads/'.$val->image)); ?>" alt=""><?php endif; ?>
           <div class="triangle">
             <img src="<?php echo e(asset('/frontend/images/bg2.png')); ?>" alt="">
           </div>
          </div>
       </div>
       <div class="col-lg-6 col-md-6 Whatwedocontent d-flex flex-wrap align-content-stretch align-items-center">
         <div class="Whatwedo_textbox">
          <h3><?php echo $val->title; ?><strong><?php echo $val->sub_title; ?></strong></h3>
           <?php echo $val->body; ?>

         </div>
       </div>
   </div>
	<?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  

 </div>
</div>


<div class="Whychoose_area p-8 pt-4">
  <div class="container">
    <div class="text-center mb-4">
      <?php $__currentLoopData = $extra_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php if($val->type==6): ?>
        <h3><?php echo $val->title; ?> <strong><?php echo $val->sub_title; ?></strong></h3>
        <?php echo $val->body; ?>

        <?php endif; ?>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div class="row row-8 howitworktotalbox">
    		<?php $__currentLoopData = $extra_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      		<?php if($val->type==7): ?>
       <div class="col-lg-3 col-md-6 col-sm-6 howitwork d-flex flex-wrap align-content-stretch">
         <div class="howitwork_box">
           <?php if($val->image && File::exists(public_path('uploads/'.$val->image)) ): ?>
             <div class="howitwork_icon" style="background-image: url(<?php echo e(asset('/uploads/'.$val->image)); ?>);"></div><?php endif; ?>
           <h3><?php echo $val->title; ?></h3>
           <?php echo $val->body; ?>

         </div>
       </div>
       <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     </div>
  </div>
</div>



	<?php $__currentLoopData = $extra_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

      <?php if($val->type==8): ?>
  <div class="Workwithus_area inneradd">
  <div class="container">
  	<?php if($val->image && File::exists(public_path('uploads/'.$val->image)) ): ?>
    <div class="Workwithus_box" style="background-image: url(<?php echo e(asset('/uploads/'.$val->image)); ?>);"><?php endif; ?>
      <div class="Workwithus_innerbox">
        
        <h4><?php echo $val->title; ?></h4>
           <?php echo $val->body; ?>

            <?php if($val->btn_url): ?><a href="<?php echo $val->btn_url; ?>" class="btn btn-custom mt-4"><?php echo $val->btn_text?$val->btn_text:'contact Us'; ?></a><?php endif; ?>
         
      </div>
    </div>
  </div>
</div>

<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>

<?php echo $__env->make('frontend.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php /**PATH /home/webtech7/public_html/project/globalization/resources/views/frontend/pages/about.blade.php ENDPATH**/ ?>