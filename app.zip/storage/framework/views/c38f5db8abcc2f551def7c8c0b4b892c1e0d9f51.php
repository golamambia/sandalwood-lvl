<?php echo $__env->make('admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php
$page_display_in_array = unserialize(Page_Display_In_Array);
$page_template_array = unserialize(Page_Template_Array);
$page_template_extra_array = unserialize(Page_Template_Extra_Array);

$allpages = get_fields_value_where('pages',"id>0",'menu_order','asc');
?>

<!-- Content Wrapper. Contains Service content -->
<div class="content-wrapper">
  <!-- Content Header (Service header) -->
  <section class="content-header">
    <h1>
      Edit Service
    </h1>
    <ol class="breadcrumb">
      <li><a href=""><i class="fa fa-dashboard"></i> Home</a></li>
      <li class="active">Edit Service</li>
    </ol>
  </section>

  
  <!-- Main content -->
  <section class="content">
    <div class="row">

      <div class="col-xm-12 col-sm-12 col-md-12">

        <div class="box box-primary">
          <div class="box-header with-border">
            <!--<h3 class="box-title">Quick Example</h3>-->
          </div>
          <!-- /.box-header -->
          <!-- form start -->
          <form role="form" action="<?php echo e(url('/admin/service/update/')); ?>"  method="post" enctype="multipart/form-data" class="formvalidation">

            <?php echo csrf_field(); ?>

            <input type="hidden" name="id" value="<?php echo e($page[0]->id); ?>">
            <input type="hidden" name="posttype" value="service">

            <div class="box-body">

              <?php if($errors->any()): ?>   
              <div class="alert alert-danger alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <h4><i class="icon fa fa-ban"></i> Alert!</h4>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($error); ?><br>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
              <?php endif; ?>

              <?php if(session()->has('success')): ?>
              <div class="alert alert-success alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <h4><i class="icon fa fa-ban"></i> Success</h4>
                Service has been updated successfully.
              </div>
              <?php endif; ?>

              <?php if(session()->has('remove_image_success')): ?>
              <div class="alert alert-success alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <h4><i class="icon fa fa-ban"></i> Success</h4>
                Image has been removed successfully. 
              </div>
              <?php endif; ?>

              <?php if(session()->has('admin_msg')): ?>
              <div class="alert alert-success alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <h4><i class="icon fa fa-ban"></i> Success</h4>
                <?php echo Session::get('admin_msg'); ?>

              </div>
              <?php endif; ?>

              <div class="form-group clearfix">
                <label class="col-sm-2 control-label">Name</label>
                <div class="col-sm-10">
                  <input type="text" class="form-control module_name" name="page_name" id="page_name" data-validation-engine="validate[required]" placeholder="Enter ..." value="<?php echo e($page[0]->page_name); ?>">
                </div>
              </div>

              <?php if($page[0]->id!='1'): ?>
              <div class="form-group clearfix">
                <label class="col-sm-2 control-label">Title</label>
                <div class="col-sm-10">
                  <input type="text" class="form-control" name="page_title" id="page_title" placeholder="Enter ..." value="<?php echo e($page[0]->page_title); ?>">
                </div>
              </div>
              <?php endif; ?>

              <div class="form-group clearfix">
                <label class="col-sm-2 control-label">Slug</label>
                <div class="col-sm-10">
                  <input type="text" class="form-control module_slug" name="slug" id="slug" placeholder="Enter ..." value="<?php echo e($page[0]->slug); ?>" data-validation-engine="validate[required]" <?php if('5'==$page[0]->id || '1'==$page[0]->id): ?> readonly <?php endif; ?>>
                </div>
              </div>

              <div class="form-group clearfix">
                <label class="col-sm-2 control-label">Parent</label>
                <div class="col-sm-4">
                  <select name="parent_id" class="form-control">
                    <option value="0">Select Parent</option>
                <?php $__currentLoopData = $all_pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo $value->id; ?>" <?php if($value->id==$page[0]->parent_id): ?> selected <?php endif; ?>><?php echo $value->page_name; ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </div>
                <label class="col-sm-2 control-label">Page Template</label>
                <div class="col-sm-4">
                  <select name="page_template" class="form-control" disabled>
                    <option value="0">Select Template</option>
                <?php $__currentLoopData = $page_template_array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo $key; ?>" <?php if($key==$page[0]->page_template): ?> selected <?php endif; ?>><?php echo $value; ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </div>
              </div><?php /**/ ?>


              <div class="form-group clearfix">
                <label class="col-sm-2 control-label">Display in</label>
                <div class="col-sm-4">
                <?php $__currentLoopData = $page_display_in_array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <label>
                  <input type="radio" name="display_in" class="flat-red" value="<?php echo e($key); ?>" <?php if($key==$page[0]->display_in): ?> checked <?php endif; ?>>
                  <?php echo $value; ?> &nbsp;&nbsp;
                </label>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <label class="col-sm-2 control-label">Menu Link</label>
                <div class="col-sm-4">
                  <select name="menu_link" class="form-control select2">
                    <option value="">Own Link</option>
                <?php $__currentLoopData = $allpages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo $value->id; ?>" <?php if($value->id==$page[0]->menu_link): ?> selected <?php endif; ?>><?php echo $value->page_name; ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </div>
              </div>

              <div class="form-group clearfix">
                <label class="col-sm-2 control-label">Menu Order</label>
                <div class="col-sm-10">
                  <input type="text" class="form-control" name="menu_order" id="menu_order" placeholder="Enter ..." value="<?php echo e($page[0]->menu_order); ?>" data-validation-engine="validate[required,custom[integer]]">
                </div>
              </div>

              <div class="form-group clearfix">
                <label class="col-sm-2 control-label">Meta Title</label>
                <div class="col-sm-10">
                  <input type="text" class="form-control" name="meta_title" placeholder="Enter ..." value="<?php echo e($page[0]->meta_title); ?>">
                </div>
              </div>

              <div class="form-group clearfix">
                <label class="col-sm-2 control-label">Meta Keyword</label>
                <div class="col-sm-10">
                  <textarea class="form-control" name="meta_keyword" placeholder="Enter ..."><?php echo e($page[0]->meta_keyword); ?></textarea>
                </div>
              </div>

              <div class="form-group clearfix">
                <label class="col-sm-2 control-label">Meta Description</label>
                <div class="col-sm-10">
                  <textarea class="form-control" name="meta_description" placeholder="Enter ..."><?php echo e($page[0]->meta_description); ?></textarea>
                </div>
              </div>

              <div class="form-group clearfix bannerimage">
                <label class="col-sm-2 control-label">Banner Image</label>
                <div class="col-sm-10">
                  <input type="file" name="bannerimage" data-validation-engine="validate[,custom[validateMIME[image/jpeg|image/jpg|image/png|image/gif|image/svg]]]" >
                  Mime Type: jpeg,png,jpg,gif,svg, Max image upload size 2 Mb<br>

                  <?php if($page[0]->bannerimage!=''): ?>
                  <div class="clearfix">
                    <?php
                    if($page[0]->bannerimage && File::exists(public_path('uploads/'.$page[0]->bannerimage)) )
                      {
                        ?>
                        <img src="<?php echo e(asset('/uploads/'.$page[0]->bannerimage)); ?>" style="margin: 10px 0 0 0;max-width: 300px;">
                        <?php
                      }
                      ?>
                  </div>
                  <?php endif; ?>

                </div>
              </div>

              <div class="form-group clearfix image2">
                <label class="col-sm-2 control-label">Icon</label>
                <div class="col-sm-10">
                  <input type="file" name="image2" data-validation-engine="validate[,custom[validateMIME[image/jpeg|image/jpg|image/png|image/gif|image/svg]]]" >
                  Mime Type: jpeg,png,jpg,gif,svg, Max image upload size 2 Mb<br>

                  <?php if($page[0]->image2!=''): ?>
                  <div class="clearfix">
                    <?php
                    if($page[0]->image2 && File::exists(public_path('uploads/'.$page[0]->image2)) )
                      {
                        ?>
                        <img src="<?php echo e(asset('/uploads/'.$page[0]->image2)); ?>" style="margin: 10px 0 0 0;max-width: 300px;">
                        <?php
                      }
                      ?>
                  </div>
                  <?php endif; ?>

                </div>
              </div>

                <?php if($page[0]->page_template<=0): ?>
                <div class="form-group clearfix">
                  <label class="col-sm-2 control-label">Page Content</label>
                  <div class="col-sm-10">
                    <textarea name="body" class="ckeditor" placeholder="Enter ..."><?php echo $page[0]->body; ?></textarea>
                  </div>
                </div>
                <?php endif; ?>

                <?php $type=''; $i=1;$content_count=0;?>
                  <div class="section_1">
                <?php $__currentLoopData = $page_extra; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if($val->type!=1 && $page[0]->page_template>0): ?>
                  <?php
                  if (($type=='' || $type!=$val->type)) {    $i++;
                    if ($type!='' && $type!=$val->type) {
                      $content_count=0;
                      echo '</div><div class="section_'.$val->type.'">';
                    }
                  ?>
                  <div class="box-header with-border" style="margin-bottom: 15px;">
                    <h3 class="box-title">Section 
                      <?php if($val->type==2 && $page[0]->id=='1'): ?> Strength 
                      <?php elseif($val->type==13): ?> Form
                      <?php else: ?> <?php echo e($i); ?> 
                      <?php endif; ?> 
                    </h3>
                  </div>
                  <?php
                  }
                    $content_count++;
                  $type = $val->type
                  ?>

                  <?php if($page[0]->page_template=='1'): ?>
                    <?php if($val->type==2 || $val->type==3 || $val->type==4 || $val->type==5 || $val->type==6 || $val->type==7 || $val->type==8 || $val->type==9 || $val->type==10 || $val->type==11 || $val->type==12 || $val->type==13 || $val->type==14 || $val->type==15): ?>
                    <div class="form-group clearfix">
                      <label class="col-sm-2 control-label">Section Title</label>
                      <div class="<?php echo e($val->type==5 || $val->type==7?'col-sm-9':'col-sm-10'); ?>">
                        <input type="text" class="form-control" name="section_title_<?php echo e($val->id); ?>" placeholder="Enter ..." value="<?php echo e($val->title); ?>">
                      </div>
                      <?php if($val->type==5 || $val->type==7): ?>
                      <div class="col-sm-1">
                        <input type="text" class="form-control" name="section_rank_<?php echo e($val->id); ?>" placeholder="Enter ..." value="<?php echo e($val->rank); ?>" data-validation-engine="validate[custom[integer]]">
                      </div>
                      <?php endif; ?>
                    </div>
                    <?php endif; ?>
                    <?php if($val->type==5): ?>
                    <div class="form-group clearfix">
                      <label class="col-sm-2 control-label">Sub Title</label>
                      <div class="col-sm-10">
                        <input type="text" class="form-control" name="section_sub_title_<?php echo e($val->id); ?>" placeholder="Enter ..." value="<?php echo e($val->sub_title); ?>">
                      </div>
                    </div>
                    <?php endif; ?>
                    <?php if($val->type==2 || $val->type==3 || $val->type==8 || $val->type==10 || $val->type==14 || $val->type==15): ?>
                    <div class="form-group clearfix">
                      <label class="col-sm-2 control-label">Image</label>
                      <div class="col-sm-10">
                        <input type="file" class="form-control" name="section_file_<?php echo e($val->id); ?>" data-validation-engine="validate[,custom[validateMIME[image/jpeg|image/jpg|image/png|image/gif|image/svg|image/webp]]]">
                        Mime Type: jpeg,png,jpg,gif,svg, Max image upload size 2 Mb<br>

                        <div class="clearfix">
                          <?php
                          if($val->image && File::exists(public_path('uploads/'.$val->image)) )
                            {
                              ?>
                              <img src="<?php echo e(asset('/uploads/'.$val->image)); ?>" style="margin: 10px 0 0 0;max-width: 200px;">
                          <?php
                            }
                          ?>
                        </div>
                      </div>
                    </div>
                    <?php endif; ?>
                    <?php if($val->type==2111 || $val->type==41): ?>
                    <div class="form-group clearfix">
                      <label class="col-sm-2 control-label">Bottom Title Image</label>
                      <div class="col-sm-10">
                        <input type="file" class="form-control" name="section_file2_<?php echo e($val->id); ?>" data-validation-engine="validate[,custom[validateMIME[image/jpeg|image/jpg|image/png|image/gif|image/svg]]]">
                        Mime Type: jpeg,png,jpg,gif,svg, Max image upload size 2 Mb<br>

                        <div class="clearfix">
                          <?php
                          if($val->image2 && File::exists(public_path('uploads/'.$val->image2)) )
                            {
                              ?>
                              <img src="<?php echo e(url('/timthumb.php')); ?>?src=<?php echo e(asset('/uploads/'.$val->image2.'&w=95&h=95&zc=3')); ?>" style="margin: 10px 0 0 0;">
                          <?php
                            }
                          ?>
                        </div>
                      </div>
                    </div>
                    <?php endif; ?>
                    <?php if($val->type=="2" || $val->type==3 || $val->type==4 || $val->type==5 || $val->type==6 || $val->type==7 || $val->type==9 || $val->type==10 || $val->type==12 || $val->type==14): ?>
                    <div class="form-group clearfix">
                      <label class="col-sm-2 control-label">Content</label>
                      <div class="col-sm-10">
                        <textarea name="section_body_<?php echo e($val->id); ?>" class="ckeditor" placeholder="Enter ..."><?php echo $val->body; ?></textarea>
                      </div>
                    </div>
                    <?php endif; ?> 
                    <?php if($val->type==2 || $val->type==3 || $val->type==8 || $val->type==13 || $val->type==15): ?>
                    <div class="form-group clearfix">
                      <label class="col-sm-2 control-label">Button Text</label>
                      <div class="col-sm-10">
                        <input type="text" class="form-control" name="section_btn_text_<?php echo e($val->id); ?>" placeholder="Enter ..." value="<?php echo e($val->btn_text); ?>">
                      </div>
                    </div>
                    <?php if($val->type!=13): ?>
                    <div class="form-group clearfix">
                      <label class="col-sm-2 control-label">Button URL</label>
                      <div class="col-sm-10">
                        <input type="text" class="form-control" name="section_btn_url_<?php echo e($val->id); ?>" placeholder="Enter ..." value="<?php echo e($val->btn_url); ?>">
                      </div>
                    </div>
                    <?php endif; ?>
                    <?php endif; ?>                 

                  <?php elseif($page[0]->page_template=='2'): ?>
                    <?php if($val->type==2 || $val->type==3): ?>
                    <?php endif; ?>
                    <div class="form-group clearfix">
                      <label class="col-sm-2 control-label">Section Title</label>
                      <div class="col-sm-10">
                        <input type="text" class="form-control" name="section_title_<?php echo e($val->id); ?>" placeholder="Enter ..." value="<?php echo e($val->title); ?>">
                      </div>
                    </div>
                    <?php if($val->type==2 || $val->type==4): ?>
                    <div class="form-group clearfix">
                      <label class="col-sm-2 control-label">Image</label>
                      <div class="col-sm-10">
                        <input type="file" class="form-control" name="section_file_<?php echo e($val->id); ?>" data-validation-engine="validate[,custom[validateMIME[image/jpeg|image/jpg|image/png|image/gif|image/svg]]]">
                        Mime Type: jpeg,png,jpg,gif,svg, Max image upload size 2 Mb<br>

                        <div class="clearfix">
                          <?php
                          if($val->image && File::exists(public_path('uploads/'.$val->image)) )
                            {
                              ?>
                              <img src="<?php echo e(url('/timthumb.php')); ?>?src=<?php echo e(asset('/uploads/'.$val->image.'&w=95&h=95&zc=3')); ?>" style="margin: 10px 0 0 0;">
                          <?php
                            }
                          ?>
                        </div>
                      </div>
                    </div>
                    <div class="form-group clearfix">
                      <label class="col-sm-2 control-label">Content</label>
                      <div class="col-sm-10">
                        <textarea name="section_body_<?php echo e($val->id); ?>" class="ckeditor" placeholder="Enter ..."><?php echo $val->body; ?></textarea>
                      </div>
                    </div> 
                    <?php endif; ?>

                  <?php elseif($page[0]->page_template=='3'): ?>
                    <?php if($val->type==2): ?>
                    <div class="form-group clearfix">
                      <label class="col-sm-2 control-label">Left Image</label>
                      <div class="col-sm-10">
                        <input type="file" class="form-control" name="section_file_<?php echo e($val->id); ?>" data-validation-engine="validate[,custom[validateMIME[image/jpeg|image/jpg|image/png|image/gif|image/svg]]]">
                        Mime Type: jpeg,png,jpg,gif,svg, Max image upload size 2 Mb<br>

                        <div class="clearfix">
                          <?php
                          if($val->image && File::exists(public_path('uploads/'.$val->image)) )
                            {
                              ?>
                              <img src="<?php echo e(url('/timthumb.php')); ?>?src=<?php echo e(asset('/uploads/'.$val->image.'&w=95&h=95&zc=3')); ?>" style="margin: 10px 0 0 0;">
                          <?php
                            }
                          ?>
                        </div>
                      </div>
                    </div> 
                    <?php endif; ?>
                    <div class="form-group clearfix">
                      <label class="col-sm-2 control-label">Section Title</label>
                      <div class="col-sm-10">
                        <input type="text" class="form-control" name="section_title_<?php echo e($val->id); ?>" placeholder="Enter ..." value="<?php echo e($val->title); ?>">
                      </div>
                    </div>
                    <?php if($val->type==3): ?>
                    <div class="form-group clearfix">
                      <label class="col-sm-2 control-label">Button Text</label>
                      <div class="col-sm-10">
                        <input type="text" class="form-control" name="section_btn_text_<?php echo e($val->id); ?>" placeholder="Enter ..." value="<?php echo e($val->btn_text); ?>">
                      </div>
                    </div>
                    <?php endif; ?>
                  <?php endif; ?> 

                  <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </div>

              <?php if($page[0]->id=='3'): ?>
                  <div class="section_4 section_faq">
                  <div class="box-header with-border" style="margin-bottom: 15px;">
                    <h3 class="box-title">FAQs</h3>
                  </div>
                <?php $__currentLoopData = $page_extra; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if($val->type==4): ?>
                  <div class="form-group clearfix">
                    <label class="col-sm-2 control-label">Questions</label>
                    <div class="col-sm-9">
                      <input type="text" class="form-control" name="section_title_<?php echo e($val->id); ?>" placeholder="Enter ..." value="<?php echo e($val->title); ?>">
                    </div>
                    <div class="col-sm-1"><a href="<?php echo e(url('/admin/page-extra/content-delete/'.$val->id)); ?>" class="">Remove</a></div>
                  </div>
                  <div class="form-group clearfix">
                    <label class="col-sm-2 control-label">Answer</label>
                    <div class="col-sm-10">
                      <textarea name="section_body_<?php echo e($val->id); ?>" class="ckeditor" placeholder="Enter ..."><?php echo e($val->body); ?></textarea>
                    </div>
                  </div>
                  <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </div>

                  <div class="form-group clearfix">
                    <label class="col-sm-2 control-label"> </label>
                    <div class="col-sm-10"><a href="javascript:;" class="btn btn-default add_faq_button">Add more FAQ</a></div>
                  </div>
              <?php endif; ?>

              <?php if($page[0]->id=='-20000'): ?>
                <?php $logo_counter=0;?>
                  <div class="section_7 section_logo">
                  <div class="box-header with-border">
                    <h3 class="box-title">Portfolio Images</h3>
                  </div>
                <?php $__currentLoopData = $page_extra; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if($val->type==7): ?>
                  <?php $logo_counter++;?>
                  <div class="form-group clearfix">
                    <label class="col-sm-2 control-label">Image <?php echo e($logo_counter); ?></label>
                    <div class="col-sm-10">
                      <input type="file" class="form-control" name="section_file_<?php echo e($val->id); ?>" data-validation-engine="validate[,custom[validateMIME[image/jpeg|image/jpg|image/png|image/gif|image/svg]]]">
                      Mime Type: jpeg,png,jpg,gif,svg, Max image upload size 2 Mb<br>

                      <div class="clearfix">
                        <?php
                        if($val->image && File::exists(public_path('uploads/'.$val->image)) )
                          {
                            ?>
                            <img src="<?php echo e(url('/timthumb.php')); ?>?src=<?php echo e(url('/uploads/'.$val->image.'&w=200&h=200&zc=3')); ?>" style="margin: 10px 0 0 0;"> <a href="<?php echo e(url('admin/page-extra/delete/'.$val->id)); ?>"> Remove</a>
                        <?php
                          }
                        ?>
                      </div>
                    </div>
                  </div>
                  <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </div>

                  <div class="form-group clearfix">
                    <label class="col-sm-2 control-label"> </label>
                    <div class="col-sm-10"><a href="javascript:;" class="btn btn-default add_logo_button">Add more Image</a></div>
                  </div>
              <?php endif; ?>

              </div>
              <!-- /.box-body -->

              <div class="box-footer">
                <button type="submit" class="btn btn-primary" name="submit" value="Submit">Submit</button>
              </div>

            </form>
          </div>
          <!-- /.box -->

        </div>


      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->

  </div>
  <!-- /.content-wrapper -->

<div class="image_container_copy hide">  
  <div class="form-group clearfix bannerimage">
    <label class="col-sm-2 control-label">Banner Image</label>
    <div class="col-sm-9">
      <input type="file" name="bannerimage" data-validation-engine="validate[,custom[validateMIME[image/jpeg|image/jpg|image/png|image/gif|image/svg]]]">
      Mime Type: jpeg,png,jpg,gif,svg, Max image upload size 2 Mb<br>
    </div>
    <div class="col-sm-1"><a href="#" class="remove_field">Remove</a></div>
  </div>
</div>

<?php echo $__env->make('admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<script type="text/javascript">
/*$(document).ready(function() {
  $("#bannertype").change(function(){
    change_bannertype(this.value);
  });
  change_bannertype(<?php echo e($page[0]->bannertype); ?>);
});

function change_bannertype(val){
  if (val==1) {
    $(".bannerimage").show('slow');
    $(".image2").hide('slow');
  }else{
    $(".bannerimage").hide('slow');
    $(".image2").show('slow');
  }  
}*/
</script>

<script type="text/javascript">
$(document).ready(function() {
  var max_fields      = 10; //maximum input boxes allowed
  var wrapper       = $(".section_faq"); //Fields wrapper
  var add_button      = $(".add_faq_button"); //Add button ID
  
  var x = 0; //initlal text box count
  $(add_button).click(function(e){ //on add input button click
    e.preventDefault();
    if(x < max_fields){ //max input box allowed
      x++; //text box increment
      $(wrapper).append('<div><div class="form-group clearfix"><label class="col-sm-2 control-label">Title</label><div class="col-sm-9"><input type="text" class="form-control" name="section_faq_new_t[]" placeholder="Enter ..." value="" data-validation-engine="validate[required]"></div><div class="col-sm-1"><a href="#" class="remove_field">Remove</a></div></div><div class="form-group clearfix"><label class="col-sm-2 control-label">Section Content</label><div class="col-sm-10"><textarea name="section_faq_new_c[]" class="ckeditor" style="width: 100%;min-height: 100px;" placeholder="Enter ..."></textarea></div></div></div>'); //add input box
    }
  });
  
  $(wrapper).on("click",".remove_field", function(e){ //Company click on remove text
    e.preventDefault(); $(this).parent('div').parent('div').parent('div').remove(); x--;
  })
});
</script>

<script type="text/javascript">
$(document).ready(function() {
  var max_fields1      = 10; //maximum input boxes allowed
  var wrapper1       = $(".section_logo"); //Fields wrapper
  var add_button1      = $(".add_logo_button"); //Add button ID
  
  var x = 0; //initlal text box count
  $(add_button1).click(function(e){ //on add input button click
    e.preventDefault();
    if(x < max_fields1){ //max input box allowed
      x++; //text box increment
      $(wrapper1).append('<div class="form-group clearfix"><label class="col-sm-2 control-label">Image</label><div class="col-sm-9"><input type="file" class="form-control" name="section_logo_new_i[]" data-validation-engine="validate[required,custom[validateMIME[image/jpeg|image/jpg|image/png|image/gif|image/svg]]]"></div><div class="col-sm-1"><a href="#" class="remove_field1">Remove</a></div></div>'); //add input box
    }
  });
  
  $(wrapper1).on("click",".remove_field1", function(e){ //Company click on remove text
    e.preventDefault(); $(this).parent('div').parent('div').remove(); x--;
  })
});
</script>

<script type="text/javascript">
$("#module_name").blur(function(){
  if($("#module_slug").val().trim()==""){
    var slug_array = $("#module_name").val().trim().replace(/[^a-z0-9\s]/gi, ' ').replace(/[_\s]/g, ' ').toLowerCase().split(" ");
    slug_array = filter_array(slug_array);
    $("#module_slug").val(slug_array.join("-"));
  }
});

$("#module_slug").blur(function(){
  if($("#module_slug").val().trim()==""){
    var slug_array = $("#module_name").val().trim().replace(/[^a-z0-9\s]/gi, ' ').replace(/[_\s]/g, ' ').toLowerCase().split(" ");
    slug_array = filter_array(slug_array);

    $("#module_slug").val(slug_array.join("-"));
  }else{
    var slug_array = $("#module_slug").val().trim().replace(/[^a-z0-9\s]/gi, ' ').replace(/[_\s]/g, ' ').toLowerCase().split(" ");
    slug_array = filter_array(slug_array);
    $("#module_slug").val(slug_array.join("-"));
  }
});
</script>
<?php /**PATH E:\wamp64\www\webtechnomind\infotree\resources\views/admin/service/edit.blade.php ENDPATH**/ ?>