<?php echo $__env->make('frontend.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php
$location = get_fields_value_where('pages',"page_template=4",'id','desc');

?>
<?php $__currentLoopData = $location; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lval): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php

$location_extra = get_fields_value_where('pages_extra',"page_id=".$lval->id,'id','desc');
?>
<?php $__currentLoopData = $location_extra; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <?php if($val->type==1): ?>
<!------ banner area start -------->
<div class="subpagr_banner" style="background-image:url(<?php echo e(asset('/uploads/'.$val->image)); ?>);">
  <div class="container">
    <h1><?php echo e($page->page_title); ?></h1>
    <nav class="breadcrumb"> <a class="breadcrumb-item" href="<?php echo e(url('/')); ?>">home</a> <a class="breadcrumb-item" href="<?php echo e(url('/')); ?>/<?php echo $lval->slug; ?>"><?php echo $lval->page_title; ?></a> <span class="breadcrumb-item active"><?php echo e($page->page_title); ?></span> </nav>
  </div>
</div>
 <?php endif; ?>
 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<!------ banner area stop --------> 

<!------ main area start -------->

<div class="mainarea p-80">
  <div class="location_img_area">
    <div class="container">
      <div class="row mb-4">
        <div class="col-lg-6">
          <?php $__currentLoopData = $extra_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($val->type==1 && ($val->image)): ?>
          <div class="location_big_img"> <img src="<?php echo e(asset('/uploads/'.$val->image)); ?>" alt="location image" title="" /> </div>
           <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="col-lg-6">
          <div class="row">
            <?php $__currentLoopData = $extra_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($val->type==4 && ($val->image)): ?>
            <div class="col-lg-6 col-md-6">
              <div class="location_small_img">
               <img src="<?php echo e(asset('/uploads/'.$val->image)); ?>" alt="location image" title="" />

                </div>
            </div>
             <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           
          </div>
        </div>
      </div>
      <div class="location_heading">
        <?php $__currentLoopData = $extra_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($val->type==1 && ($val->title)): ?>
        <h2><?php echo $val->title; ?></h2>
         <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <h3><img src="<?php echo e(asset('frontend')); ?>/images/location-icon.png" alt="location icon" title="" class="location-icon" /><strong>Location:</strong> <?php $__currentLoopData = $extra_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($val->type==2 && ($val->body)): ?>
     <?php echo e(strip_tags($val->body)); ?>

        <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></h3>
      </div>
      <div class="row">
        <div class="col-lg-8">
         
          <div class="overview_area box_shadow">
            <h3>Description:</h3>
            <?php $__currentLoopData = $extra_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($val->type==1 && ($val->body)): ?>
        <?php echo $val->body; ?>

         <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
          <div class="overview_area box_shadow">
            <h3>Details:</h3>
            <div class="row">
              <?php $__currentLoopData = $extra_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($val->type==3 ): ?>
              <div class="col-lg-4">
                <p><?php echo $val->title; ?></p>
                <p><?php echo $val->sub_title; ?></p>
              </div>
              <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
          </div>
        </div>
        <div class="col-lg-4">
          <div class="overview_area box_shadow">
            <h3>Property Information:</h3>
            <div class="information_box"> <img src="<?php echo e(asset('frontend')); ?>/images/location-icon.png" alt="location icon" title="" class="img_icon" />
              <h5>Location:</h5>
              <p><?php $__currentLoopData = $extra_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($val->type==2 && ($val->body)): ?>
     <?php echo e(strip_tags($val->body)); ?>

        <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></p>
            </div>
            <div class="information_box"> <img src="<?php echo e(asset('frontend')); ?>/images/phone-icon.png" alt="phone icon" title="" class="img_icon" />
              <h5>Phone:</h5>
              <p> <?php $__currentLoopData = $extra_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($val->type==2 && ($val->title)): ?>
     <?php echo $val->title; ?>

        <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></p>
            </div>
            <div class="information_box"> <img src="<?php echo e(asset('frontend')); ?>/images/fax-icon.png" alt="fax icon" title="" class="img_icon" />
              <h5>Fax:</h5>
              <p><?php $__currentLoopData = $extra_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($val->type==2 && ($val->sub_title)): ?>
     <?php echo $val->sub_title; ?>

        <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></p>
            </div>
            <div class="information_box"> <img src="<?php echo e(asset('frontend')); ?>/images/mail-icon.png" alt="mail icon" title="" class="img_icon" />
              <h5>Email:</h5>
              <p><?php $__currentLoopData = $extra_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($val->type==2 && ($val->btn_text)): ?>
     <?php echo $val->btn_text; ?>

        <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></p>
            </div>
            <div class="information_box"> <img src="<?php echo e(asset('frontend')); ?>/images/web.png" alt="web" title="" class="img_icon" />
              <h5>Website:</h5>
              <p><?php $__currentLoopData = $extra_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($val->type==2 && ($val->btn_url)): ?>
     <?php echo $val->btn_url; ?>

        <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></p>
            </div>
            <button type="submit" class="btn btn-primary w-100">Open In Google Maps</button>
          </div>
        </div>
        
      </div>
    </div>
  </div>
</div>
<!------ main area stop --------> 

<?php echo $__env->make('frontend.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/webtech7/public_html/project/sandalwood/resources/views/frontend/pages/location_details.blade.php ENDPATH**/ ?>