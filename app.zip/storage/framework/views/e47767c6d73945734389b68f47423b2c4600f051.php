<?php echo $__env->make('frontend.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php $__currentLoopData = $extra_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <?php if($val->type==1): ?>
<!------ banner area start -------->
<div class="subpagr_banner" style="background-image:url(<?php echo e(asset('/uploads/'.$val->image)); ?>);">
  <div class="container">
     <?php if($val->title): ?><h1><?php echo $val->title; ?></h1><?php endif; ?>
    
    <nav class="breadcrumb"> <a class="breadcrumb-item" href="<?php echo e(url('/')); ?>">home</a> <span class="breadcrumb-item active"><?php echo e($page->page_title); ?></span> </nav>
  </div>
</div>
<!------ banner area stop --------> 
 <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<!------ main area start -------->


<div class="mainarea p-80">
  <div class="contact_page">
    <div class="container">
      
      <div class="contact_pageformbox mt-0">
          <?php $__currentLoopData = $extra_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <?php if($val->type==2): ?>
          <h2><?php echo $val->title; ?></h2>
          <p><?php echo $val->sub_title; ?></p>
           <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 <?php if($errors->any()): ?>   
            <div class="alert alert-danger alert-dismissible">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            <h4><i class="icon fa fa-ban"></i> Alert!</h4>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo e($error); ?><br>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php endif; ?>
           <form method="POST" action="<?php echo e(url('book_appoinment')); ?>" class="customvalidation">
           <?php echo csrf_field(); ?>
            <div class="row">
              <div class="col-lg-12">
                <div class="row row-8">
                  <div class="col-lg-6">
                    <div class="form-group">
                      <input type="text" class="form-control" data-validation-engine="validate[required]" name="name" value="<?php echo e(old('name')); ?>" placeholder=" Name*">
                    </div>
                  </div>
                 
                  <div class="col-lg-6">
                    <div class="form-group">
                      <input type="email" class="form-control" data-validation-engine="validate[required]" name="email" value="<?php echo e(old('email')); ?>" placeholder="Email*">
                    </div>
                  </div>
                  <div class="col-lg-6">
                    <div class="form-group">
                     <input type="text" class="form-control numeric_input"placeholder="Phone*" data-validation-engine="validate[required]" name="phone" maxlength="10" value="<?php echo e(old('phone')); ?>">
                    </div>
                  </div>
                   <div class="col-lg-6">
                    <div class="form-group">
                      <input type="text" class="form-control" data-validation-engine="validate[required]" name="address" value="<?php echo e(old('address')); ?>" placeholder="booking Locations" >
                    </div>
                  </div>
                   <div class="col-lg-6">
                    <div class="form-group">
                      <input type="date" class="form-control" name="book_date" placeholder="date*" data-validation-engine="validate[required]" value="<?php echo e(old('book_date')); ?>">
                    </div>
                  </div>
                  <div class="col-lg-6">
                    <div class="form-group">
                      <input type="text" class="form-control" name="book_time" readonly placeholder="time" data-validation-engine="validate[required]" value="<?php echo e(old('book_time')); ?>">
                    </div>
                  </div>
                  <div class="col-lg-12">
              <div class="form-group">
                     <textarea class=" form-control" placeholder="Message" name="message"><?php echo e(old('message')); ?></textarea>
                    </div>
                    <?php $__currentLoopData = $extra_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <?php if($val->type==3): ?>
                    <input type="submit" class="btn btn-primary" value="<?php echo $val->btn_text?$val->btn_text:'Submit now'; ?>" name="">
              <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
                </div>
              </div>
              
            </div>
          </form>
      </div>
    </div>
  </div>
</div>
<!------ main area stop --------> 
   
<?php echo $__env->make('frontend.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 <script src="<?php echo e(asset("/frontend/js/timepick.js")); ?>"></script> 

   <script type="text/javascript">
    $(document).ready(function(){
        $('input[name="book_time"]').ptTimeSelect();
    });
</script><?php /**PATH /home/webtech7/public_html/project/sandalwood/resources/views/frontend/pages/book_appoinment.blade.php ENDPATH**/ ?>