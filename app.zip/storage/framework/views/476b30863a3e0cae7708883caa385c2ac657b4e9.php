<?php echo $__env->make('frontend.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <div id="carouselExampleControls" class="carousel slide bs-slider box-slider" data-ride="carousel"
        data-pause="hover" data-interval="false"> 
        <ol class="carousel-indicators">
          <?php $count=0;?>
          <?php $__currentLoopData = $extra_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($val->type==1 && $val->image && File::exists(public_path('uploads/'.$val->image))): ?>
            <li data-target="#carouselExampleControls" data-slide-to="<?php echo $count; ?>" class="<?php echo $count=='0'?'active':''; ?>"></li>
            <?php $count++; ?>
            <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ol>
        <div class="carousel-inner" role="listbox">
          <?php $count=0;?>
          <?php $__currentLoopData = $extra_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($val->type==1 && $val->image && File::exists(public_path('uploads/'.$val->image))): ?>
            <div class="carousel-item <?php echo $count=='0'?'active':''; ?>">
                <div id="home" class="first-section" style="background-image:url('<?php echo e(asset('/frontend/images/slider-01.jpg')); ?>');">
                    <div class="dtab">
                        <div class="container">
                            <div class="row">
                                <div class="col-lg-6 col-md-6 col-sm-12" data-aos-once="true" data-aos="fade-right">
                                    <div class="big-tagline">
                                        <?php if($val->title): ?><h4><?php echo $val->title; ?></h4><?php endif; ?>
                                        <?php if($val->sub_title): ?><h2><?php echo $val->sub_title; ?></h2><?php endif; ?>
                                        <?php if($val->body): ?><p class="lead"><?php echo $val->body; ?></p><?php endif; ?>
                                        <?php if($val->btn_url): ?><a href="<?php echo $val->btn_url; ?>" class="hover-btn-new"><span><?php echo $val->btn_text?$val->btn_text:'Learn More'; ?></span></a><?php endif; ?>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-12" >
                                    <div class="slider-img" data-aos-once="true" data-aos="fade-up">
                                        <img src="<?php echo e(asset('/uploads/'.$val->image)); ?>">
                                    </div>
                                </div>
                            </div><!-- end row -->
                        </div><!-- end container -->
                    </div>
                </div><!-- end section -->
            </div>
            <?php $count++; ?>
            <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <!-- Left Control -->
            <a class="new-effect carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
                <span class="fa fa-angle-left" aria-hidden="true"></span>
                <span class="sr-only">Previous</span>
            </a>

            <!-- Right Control -->
            <a class="new-effect carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
                <span class="fa fa-angle-right" aria-hidden="true"></span>
                <span class="sr-only">Next</span>
            </a>
        </div>
    </div>


    <div id="overviews" class="section">
        <div class="container">

    <?php $__currentLoopData = $extra_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php if($val->type==2): ?>
            <div class="row align-items-center">
                <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12" data-aos-once="true" data-aos="fade-up">
                    <div class="img-box">
                        <?php if($val->image && File::exists(public_path('uploads/'.$val->image)) ): ?><img src="<?php echo e(asset('/uploads/'.$val->image)); ?>" alt="" class="img-fluid img-rounded">
                        <div class="img-after">
                            <span><img src="<?php echo e(asset('/frontend/images/triangle-sm.svg')); ?>"></span>
                            <span><img src="<?php echo e(asset('/frontend/images/triangle-sm1.svg')); ?>"></span>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12" data-aos-once="true" data-aos="fade-left">
                    <div class="message-box lg-txt-div">
                        <?php if($val->title): ?><h3 class="title"><?php echo $val->title; ?></h3><?php endif; ?>
                        <?php echo $val->body; ?>


                        <?php if($val->btn_url): ?><a href="<?php echo $val->btn_url; ?>" class="hover-btn-new mt-4"><span><?php echo $val->btn_text?$val->btn_text:'Contact Us'; ?> &nbsp; <span><img src="<?php echo e(asset('/frontend/images/arrow.svg')); ?>" /></span></span></a><?php endif; ?>
                    </div><!-- end messagebox -->
                </div>
            </div>
      <?php endif; ?>
      <?php
      if ($val->type==3) {
        $section_3_title = $val->title;
        $section_3_body = $val->body;
      }
      if ($val->type==5) {
        $section_5_title = $val->title;
        $section_5_body = $val->body;
        $section_5_image = $val->image;
      }
      if ($val->type==6) {
        $section_6_title = $val->title;
      }
      if ($val->type==7) {
        $section_7_title = $val->title;
        $section_7_btn_text = $val->btn_text;
      }
      if ($val->type==8) {
        $section_8_title = $val->title;
      }
      if ($val->type==10) {
        $section_10_title = $val->title;
        $section_10_body = $val->body;
        $section_10_image = $val->image;
        $section_10_btn_text = $val->btn_text;
        $section_10_btn_url = $val->btn_url;
      }
      if ($val->type==11) {
        $section_11_btn_text = $val->btn_text;
        $section_11_btn_url = $val->btn_url;
      }
      if ($val->type==12) {
        $section_12_title = $val->title;
      }
      ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

    <div class="section" id="why">
        <div class="container">
            <div class="section-title row text-center" data-aos-once="true" data-aos="fade-up">
                <div class="col-md-12">

                    <h3 class="title text-center"><?php echo $section_3_title; ?></h3>
                    <div class="lg-txt-div"><?php echo $section_3_body; ?></div>

                </div>
            </div>
            <div class="row align-items-center">
                <?php $count=$counter=0; ?>
    <?php $__currentLoopData = $extra_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php if($val->type==4): ?>
                <?php $count++;$counter++;
                if ($count==1) {
                    $aos='fade-right';
                    $card='wt';
                }elseif ($count==2) {
                    $aos='fade-up';
                    $card='';
                }elseif ($count==3) {
                    $aos='fade-left';
                    $card='wt';
                    $count=0;
                }else {
                    $aos='';
                    $card='';
                }
                ?>
                <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12"  data-aos-once="true" data-aos="<?php echo $aos; ?>">
                    <div class="card <?php echo $card; ?>">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-lg-2 col-md-2">
                                    <div class="bg-box">
                                        <?php echo $counter; ?>

                                    </div>
                                </div>
                                <div class="col-lg-10 col-md-10">
                                    <h3 class="card-title"><?php echo $val->title; ?></h3>
                                </div>
                                <div class="col-lg-12">
                                    <div class="pt-5"><?php echo $val->body; ?></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
      <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>

    <div class="section"> 
        <div class="row align-items-center">
            <div class="col-xl-7 col-lg-7 col-md-12 col-sm-12" data-aos-once="true" data-aos="fade-right">
                <div class="our-service">
                    <div class="container">

                        <div class="col-md-10">
                            <h3 class="title"><?php echo $section_5_title; ?></h3>
                            <?php echo $section_5_body; ?>

                            <?php if($val->btn_url): ?><a href="<?php echo $val->btn_url; ?>" class="hover-btn-new"><span><?php echo $val->btn_text?$val->btn_text:'Contact Us'; ?> &nbsp; <span><img src="<?php echo e(asset('/frontend/images/arrow.svg')); ?>" /></span></span></a><?php endif; ?>
                        </div>
                        <div class="img-after">
                            <span><img src="<?php echo e(asset('/frontend/images/triangle-sm.svg')); ?>"></span>
                            <span><img src="<?php echo e(asset('/frontend/images/triangle-sm1.svg')); ?>"></span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-5 col-lg-5 col-md-12 col-sm-12" data-aos-once="true" data-aos="fade-left">
                <div class="img-double">
                    <?php if($section_5_image && File::exists(public_path('uploads/'.$section_5_image))): ?><img src="<?php echo e(asset('/uploads/'.$section_5_image)); ?>" alt="" class="img-fluid img-rounded"><?php endif; ?>
                    <div class="img-after">
                        <span><img src="<?php echo e(asset('/frontend/images/triangle-sm.svg')); ?>"></span>
                        <span><img src="<?php echo e(asset('/frontend/images/triangle-sm1.svg')); ?>"></span>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div id="service" class="section">
        <div class="container">
            <?php if($section_6_title): ?><h3 class="title text-center"><?php echo $section_6_title; ?></h3><?php endif; ?>
            <div class="row align-items-center">

                <?php
                $services = get_fields_value_where('pages',"posttype='service' and parent_id='0'",'menu_order','asc',6);//
                $count=0;
                foreach ($services as $key => $value) {
                    $count++;
                    if ($count==1) {
                        $aos='fade-right';
                        $card='wt';
                    }elseif ($count==2) {
                        $aos='fade-up';
                        $card='';
                    }elseif ($count==3) {
                        $aos='fade-left';
                        $card='wt';
                        $count=0;
                    }else {
                        $aos='';
                        $card='';
                    }
                    $slug = $value->slug;
                    if ($value->menu_link>0) {
                      $slug = get_field_value('pages',"slug",'id',$value->menu_link);
                    }
                ?>
                <div class="col-xl-4 col-lg-4 p-0 col-md-6 col-sm-12" data-aos-once="true" data-aos="<?php echo e($aos); ?>">
                    <div class="card <?php echo e($card); ?>">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-lg-12 col-md-12">
                                    <div class="icon">
                                        <?php if($value->image2 && File::exists(public_path('uploads/'.$value->image2))): ?><img src="<?php echo e(asset('/uploads/'.$value->image2)); ?>" alt=""><?php endif; ?>
                                    </div>
                                </div>
                                <div class="col-lg-12 col-md-12">
                                    <h3 class="card-title text-center"><?php echo $value->page_name; ?></h3>
                                </div>
                                <div class="col-lg-12">
                                    <p class="pt-5"><?php echo description_show($value->body); ?></p>
                                    <a href="<?php echo e(url('/'.$slug)); ?>" class="hover-btn-new"><span>Read More</span></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php
                }
                ?>
            </div>
        </div>
    </div>
    <div class="section" id="contact_home">
        <div class="container">
            <div class="get-intouch  align-items-center" data-aos-once="true" data-aos="fade-up">
            <?php if($errors->any()): ?>   
            <div class="alert alert-danger alert-dismissible">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            <h4><i class="icon fa fa-ban"></i> Alert!</h4>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo e($error); ?><br>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php endif; ?>
                <form method="POST" action="<?php echo e(url('contact')); ?>" class="customvalidation_bottom">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="action" value="contact_home">
                <div class="row">
                    <div class="col-lg-2 col-md-12 col-sm-6 col-xs-12">
                        <h3><?php echo $section_7_title; ?></h3>
                    </div>
                    <div class="col-lg-2 pt-2 col-md-6 col-sm-6 col-xs-12">
                        <input type="text" class="form-control" placeholder="Your Name*" data-validation-engine="validate[required]" name="name" value="<?php echo e(old('name')); ?>">
                    </div>
                    <div class="col-lg-2 pt-2 col-md-6 col-sm-6 col-xs-12">
                        <input type="text" class="form-control" placeholder="Email ID*" data-validation-engine="validate[required,custom[email]]" name="email" value="<?php echo e(old('email')); ?>">
                    </div>
                    <div class="col-lg-2 pt-2 col-md-6 col-sm-6 col-xs-12">
                        <input type="text" class="form-control" placeholder="Phone Number" name="phone" value="<?php echo e(old('phone')); ?>">
                    </div>
                    <div class="col-lg-2 pt-2 col-md-6 col-sm-6 col-xs-12">
                        <select class="form-control select2" name="service" data-validation-engine="validate[required]">
                            <option value="">Select Service</option>
            <?php
            $services = get_fields_value_where('pages',"posttype='service'",'menu_order','asc');// and parent_id='0'
            foreach ($services as $key => $value) {
            ?>
                            <option value="<?php echo $value->page_name; ?>" <?php echo old('service')==$value->page_name?'selected':''; ?>><?php echo $value->page_name; ?></option>
            <?php
            }
            ?>
                        </select>
                    </div>
                    <div class="col-lg-2 col-md-12 psy-2 col-sm-6 col-xs-12">
                        <button type="submit" class="hover-btn-new"><?php echo $section_7_btn_text?$section_7_btn_text:'Submit'; ?> </button>
                    </div>
                </div>
                </form>
            </div>
        </div>
    </div>

    <section class="section">
        <div class="container">
            <div class="section-title row text-center">
                <div class="col-md-10 offset-md-1" data-aos-once="true" data-aos="fade-up">
                    <h3 class="title text-center mb-4"><?php echo $section_8_title; ?></h3>
                </div>
                <div class="container">
                    <div class="row">
                        <?php $count=0; ?>
                        <?php $__currentLoopData = $extra_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <?php if($val->type==9): ?>
                            <?php $count++;
                            if ($count==1) {
                                $aos='fade-right';
                                $width='60';
                            }elseif ($count==2) {
                                $aos='fade-up';
                                $width='80';
                            }elseif ($count==3) {
                                $aos='fade-left';
                                $width='70';
                                $count=0;
                            }else {
                                $aos='';
                                $width='';
                            }
                            ?>
                        <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12" data-aos-once="true" data-aos="<?php echo $aos; ?>">
                            <div class="card wt">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-lg-6 col-md-12">
                                            <h3 class="cd-title"><?php echo $val->sub_title; ?></h3>
                                        </div>
                                        <div class="col-lg-6 col-md-12">
                                            <div class="pull-right ahead-icon">
                                                <?php if($val->image && File::exists(public_path('uploads/'.$val->image)) ): ?><img width="<?php echo $width; ?>" src="<?php echo e(asset('/uploads/'.$val->image)); ?>" alt=""><?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-12 col-md-12">
                                        <h2 class="ct-title"><?php echo $val->title; ?></h2>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <div class="founder"> 
        <div class="container-fluid">
           <div class="row">
            <div class="col-xl-7 col-lg-7 col-md-12 col-sm-12">
                <div class="py-40 " data-aos-once="true" data-aos="fade-left">
                    <h3 class="title"><?php echo $section_10_title; ?></h3>
                    <?php echo $section_10_body; ?>

                    
                    <div class="col-lg-8 col-md-6">
                        <?php if($section_10_btn_url): ?><a href="<?php echo $section_10_btn_url; ?>" class="hover-btn-new mr-8"><span><?php echo $section_10_btn_text?$section_10_btn_text:'Watch Video'; ?></span></a><?php endif; ?>

                        <?php if($section_11_btn_url): ?><a href="<?php echo $section_11_btn_url; ?>" class="hover-btn-new"><span><?php echo $section_11_btn_text?$section_11_btn_text:'Contact Us'; ?>

                        </span></a><?php endif; ?>

                    </div>
                    <div class="img-after">
                        <span><img src="<?php echo e(asset('/frontend/images/triangle-sm.svg')); ?>"></span>
                        <span><img src="<?php echo e(asset('/frontend/images/triangle-sm1.svg')); ?>"></span>
                    </div>
                </div>
            </div> 
            <div class="col-xl-5 col-lg-5 col-md-12 col-sm-12" data-aos-once="true" data-aos="fade-right">
                <div class="found-img">
                    <?php if($section_10_image && File::exists(public_path('uploads/'.$section_10_image))): ?><img src="<?php echo e(asset('/uploads/'.$section_10_image)); ?>" alt="" class="img-fluid img-rounded"><?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="test-sec">
    <div class="col-md-10 offset-md-1" data-aos-once="true" data-aos="fade-up"> 
        <h3 class="title"><?php echo $section_12_title; ?></h3>
    </div>
    <?php if($testimonials->count()>0): ?>
    <div class="container">
        <div class="testiSlide"> 
            <?php $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div>
                <figure class="testimonial"> 
                  <div class="card wt">
                    <div class="row">
                        <div class="col-lg-12 col-md-12">
                            <h3 class="card-title"><?php echo $val->title; ?></h3>
                        </div>
                        <div class="col-lg-12 col-md-12">
                            <div class="rating"><?php echo get_rating_html($val->rating); ?></div>
                        </div>
                        <div class="col-md-12">
                            <?php echo $val->body; ?>

                            <h3 class="footer-title"><?php echo $val->name; ?></h3> 
                        </div>
                    </div>
                </figure>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </div>
    <?php endif; ?>
</div>

<?php $__env->startSection('more-scripts'); ?>
<?php if(old('action')=='contact_home'): ?> 
<script>
  $(document).ready(function() {
    $('html,body').animate({
        scrollTop: $("#<?php echo e(old('action')); ?>").offset().top-200
    }, 700);
  });
</script>
<?php endif; ?>
<script>
$(document).ready(function() { 
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH E:\wamp64\www\webtechnomind\infotree\resources\views/frontend/home.blade.php ENDPATH**/ ?>