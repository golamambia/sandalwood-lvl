<?php echo $__env->make('frontend.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php
$location_type = get_fields_value_where('pages',"posttype='location'",'id','desc');
?>

<!------ banner area start -------->
<div class="home-slider">
  <div class="cycle-slideshow home-slideshow" data-cycle-slides="&gt; div" data-cycle-pager=".home-pager" data-cycle-timeout="5000" data-cycle-prev="#HomePrev" data-cycle-next="#HomeNext">
    <?php $__currentLoopData = $extra_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($val->type==1 && $val->image && File::exists(public_path('uploads/'.$val->image))): ?>
    
    <div class="slide" style="background-image:url(<?php echo e(asset('/uploads/'.$val->image)); ?>);">
      <div class="caption">
        <div class="container">
          <div class="con">
            <h2><?php echo $val->title; ?></h2>
            <p><?php echo $val->sub_title; ?></p>
            <a href="<?php echo $val->btn_url; ?>" class="btn btn-primary"><?php echo $val->btn_text?$val->btn_text:'Contact us'; ?></a> </div>
        </div>
      </div>
    </div>
     <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



  </div>
</div>
<!------ banner area stop --------> 
<!-------About Us start  ------->
<div class="aboutus_area">
  <div class="container">
    <div class="row">
      <div class="col-lg-6 col-md-6">
       
       
        
    
    
        <div class="aboutus_thumble">
         <?php $__currentLoopData = $extra_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
          <?php if($val->type==2 && $val->image && File::exists(public_path('uploads/'.$val->image))): ?>
          <img src="<?php echo e(asset('/uploads/'.$val->image)); ?>" alt="#">
           <?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php $__currentLoopData = $extra_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <?php if($val->type==2 && $val->title): ?>
          <div class="since">
            <h5><span><img src="<?php echo e(asset('frontend')); ?>/images/about_icon3.png" alt=" "></span><?php echo $val->title; ?></h5>
          </div>
          <?php endif; ?>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
 
 
      </div>
      <div class="col-lg-6 col-md-6">
        <div class="aboutus_contantbox">
           <?php $__currentLoopData = $extra_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <?php if($val->type==3): ?>
          <h2><?php echo $val->title; ?></h2>
          <?php echo $val->body; ?>

           <?php endif; ?>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             <?php $__currentLoopData = $extra_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <?php if($val->type==4): ?>
          <div class="whybox">
            <div class="whyicon"><img src="<?php echo e(asset('/uploads/'.$val->image)); ?>" alt=" "></div>
            <h4><?php echo $val->title; ?></h4>
            <p><?php echo $val->sub_title; ?></p>
          </div>
         <?php endif; ?>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
      </div>
    </div>
  </div>
</div>
<!-------About Us stop  -------> 

<!------- Higher Standard start  ------->
<div class="ourservices_area p-8">
  <div class="container">
       <?php $__currentLoopData = $extra_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <?php if($val->type==5): ?>
    <div class="d-flex justify-content-between">
      <div class="d-block">
        <h2><?php echo $val->title; ?></h2>
      </div>
      <?php echo $val->body; ?>

    </div>
    <?php endif; ?>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <div class="owl-carousel service_carousel" id="servicecarousel">
       <?php $__currentLoopData = $extra_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <?php if($val->type==6): ?>
      <div class="ourservices_box">
             
       <a href="#">
        <div class="ourservices_thumble d-flex"> <img src="<?php echo e(asset('/uploads/'.$val->image)); ?>" alt="#">
          <div class="overbox">
            <div class="icon" style="background-image: url(<?php echo e(asset('/uploads/'.$val->image2)); ?>);"></div>
            <h4><?php echo $val->title; ?></h4>
            <p><?php echo $val->sub_title; ?></p>
          </div>
        </div>
        </a> </div>
        <?php endif; ?>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
    </div>
  </div>
</div>
<!------- Higher Standard start  -------> 

<!------- Book an Appointment start  ------->
<div class="bookan" style="background:url(<?php echo e(asset('frontend')); ?>/images/bookanbg.jpg)">
  <div class="container">
     <?php $__currentLoopData = $extra_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <?php if($val->type==7): ?>
    <h2><?php echo $val->title; ?></h2>
  <?php echo $val->body; ?> 
  <?php endif; ?>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    

    <div class="text-center"> 
 <?php $__currentLoopData = $extra_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <?php if($val->type==7 && $val->btn_text): ?>
      <a href="/contact-us" class="callus"><?php echo $val->btn_text; ?></a>
 <?php endif; ?>
  <?php if($val->type==8 && $val->btn_text): ?>
       <a href="/contact-us" class="callus"><?php echo $val->btn_text; ?></a>
 <?php endif; ?>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
  </div>
</div>
<!------- Book an Appointment stop  -------> 

<!------- Why Choose Us start  ------->
<div class="whyus">
  <div class="container">
     <?php $__currentLoopData = $extra_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <?php if($val->type==8): ?>
     <h2><?php echo $val->title; ?></h2>
  <?php echo $val->body; ?> 
  <?php endif; ?>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <div class="row">
      <div class="col-lg-7">
        <?php $__currentLoopData = $extra_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <?php if($val->type==9): ?>
        <div class="whybox">
          <div class="whyicon"><img src="<?php echo e(asset('/uploads/'.$val->image)); ?>" alt=" "></div>
          <h4><?php echo $val->title; ?></h4>
          <p><?php echo $val->sub_title; ?></p>
        </div>
          <?php endif; ?>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


      </div>
      <div class="col-lg-5">
        <div class="story_video"> 
                  <?php $__currentLoopData = $extra_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <?php if($val->type==10): ?><img src="<?php echo e(asset('frontend')); ?>/images/videoimg.jpg" alt="video" title=""> 
           <a  data-fancybox href="<?php echo $val->btn_url; ?>" class="video-play-button"><span></span></a>
 <?php endif; ?>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
      </div>
    </div>
  </div>
</div>
<!------- Why Choose Us stop  -------> 

<!------- What we do start  ------->
<div class="Whatwedo_area p-8">
  <div class="container">
    <?php $__currentLoopData = $extra_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <?php if($val->type==10): ?>
    <h2><?php echo $val->title; ?></h2>
    <p><?php echo $val->sub_title; ?></p>
    <?php endif; ?>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php $__currentLoopData = $extra_data2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <?php if($val->type==2): ?>
    <div class="Whatwedo_box row">
      <div class="col-lg-6 col-md-6 Whatwedoimg d-flex flex-wrap align-content-stretch">
        <div class="Whatwedo_thumble d-flex"> <img src="<?php echo e(asset('/uploads/'.$val->image)); ?>"> </div>
      </div>
      <div class="col-lg-6 col-md-6 Whatwedocontent d-flex flex-wrap align-content-stretch align-items-center">
        <div class="Whatwedo_textbox">
          <h3><?php echo e(strip_tags($val->title)); ?></h3>
          <?php echo $val->body; ?>

           <?php if($val->btn_text): ?><a href="<?php echo e(url('/service/'.$val->id)); ?>" class="more"><?php echo $val->btn_text?$val->btn_text:'read more'; ?></a><?php endif; ?> </div>
      </div>
    </div>
    <?php endif; ?>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  
  </div>
</div>
<!------- What we do stop  -------> 
<!------- Clients Say start -------> 

<div class="clientsay_area p-8">
  <div class="container">
    <?php $__currentLoopData = $extra_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <?php if($val->type==10): ?>
    <h2><?php echo $val->title; ?></h2>
    <p><?php echo $val->sub_title; ?></p>
     <?php endif; ?>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
  <div class="row m-0">
      
      
        <div class="client_rightbox">
         
          
           <div class="owl-carousel client-carousel" id="clientslider">
    <?php if($location_type->count() > 0): ?>
 <?php $__currentLoopData = $location_type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lt_val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
 <?php
$extra_datanw = get_fields_value_where('pages_extra',"page_id=".$lt_val->id,'id','desc');
?>
            <a href="<?php echo e(url('/')); ?>/<?php echo $lt_val->slug; ?>">
            <div class="clientbox">
              <div class="locationimg">
                 <?php $__currentLoopData = $extra_datanw; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($val->type==1 && ($val->image)): ?>
            <img src="<?php echo e(asset('/uploads/'.$val->image)); ?>" alt=" ">
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <h4>
        <?php $__currentLoopData = $extra_datanw; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($val->type==1 && ($val->title)): ?>
     <?php echo $val->title; ?>

        <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </h4>
              </div>
            </div>
          </a>

             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php endif; ?>
          </div>
        
      </div>
    </div>
</div>

<!------- Clients Say stop -------> 
<!------- Our Latest News start  ------->
<div class="latest pt-0">
  <div class="container">
    <?php $__currentLoopData = $extra_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <?php if($val->type==12): ?>
    <h2><?php echo $val->title; ?></h2>
   <?php echo $val->body; ?>

    <?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <div class="row">
      <?php $__currentLoopData = $extra_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <?php if($val->type==13): ?>
      <div class="col-lg-4 col-md-4">
        <div class="newbox">
          <div class="newimg"><img src="<?php echo e(asset('/uploads/'.$val->image)); ?>" alt=" ">
            <div class="clock"><i class="fa fa-clock-o" aria-hidden="true"></i><?php echo $val->sub_title; ?></div>
          </div>
          <div class="ntxt">
            <h4><a href="javascript:void(0)"><?php echo $val->title; ?></a></h4>
            <?php echo $val->body; ?>

          </div>
        </div>
      </div>
<?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      


    </div>
  </div>
</div>
<!------- Our Latest News stop  -------> 

<!------- How can we help start  ------->
<div class="wehelp">
  <div class="container">
    <div class="row shadow">
      <div class=" col-lg-6 p-0">
        <div class="map">
          <?php $__currentLoopData = $extra_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <?php if($val->type==14): ?>
          <iframe src="<?php echo $val->sub_title; ?>" width="100%" height="525px" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
<?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      </div>
      <div class="col-lg-6 p-5">
        <?php $__currentLoopData = $extra_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <?php if($val->type==14): ?>
        <h2><?php echo $val->title; ?></h2>
        <?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               <?php if($errors->any()): ?>   
            <div class="alert alert-danger alert-dismissible">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            <h4><i class="icon fa fa-ban"></i> Alert!</h4>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo e($error); ?><br>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php endif; ?>
       <form method="POST" action="<?php echo e(url('homeform')); ?>" class="customvalidation">
           <?php echo csrf_field(); ?>
          <div class="form-check">
            <input class="form-check-input" type="radio" name="exampleRadios" id="exampleRadios1" value="option1" checked>
            <label class="form-check-label" for="exampleRadios1"> Pricing & Availability </label>
          </div>
          <div class="form-check">
            <input class="form-check-input" type="radio" name="exampleRadios" id="exampleRadios2" value="option1" checked>
            <label class="form-check-label" for="exampleRadios2"> Schedule a Tour </label>
          </div>
          <div class="form-check">
            <input class="form-check-input" type="radio" name="exampleRadios" id="exampleRadios3" value="option1" checked>
            <label class="form-check-label" for="exampleRadios3"> Employment </label>
          </div>
          <div class="form-group">
            <input type="text" class="form-control numeric_input" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Your Name" data-validation-engine="validate[required]" name="name" maxlength="10" value="<?php echo e(old('name')); ?>">
          </div>
          <div class="form-group">
            <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Your Email" data-validation-engine="validate[required]" name="email" value="<?php echo e(old('email')); ?>">
          </div>
          <div class="form-group">
            <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Your Phone" maxlength="10" data-validation-engine="validate[required]" name="phone" value="<?php echo e(old('phone')); ?>">
          </div>
          <button type="submit" class="btn btn-primary">Get Started</button>
        </form>
      </div>
    </div>
  </div>
</div>
<!------- How can we help stop  -------> 

<?php $__env->startSection('more-scripts'); ?>

<script>
$(document).ready(function() { 
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php /**PATH /home/webtech7/public_html/project/sandalwood/resources/views/frontend/home.blade.php ENDPATH**/ ?>