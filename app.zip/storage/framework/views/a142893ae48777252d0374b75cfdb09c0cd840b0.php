<?php
print_r($content)
?><?php /**PATH /home/webtech7/public_html/project/sandalwood/resources/views/mail.blade.php ENDPATH**/ ?>