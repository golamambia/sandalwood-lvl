<?php
$footer_menu_page = get_fields_value_where('pages',"(display_in='2' or display_in='3') and posttype='page'",'menu_order','asc');
?>
<div class="footer ">
        <div class="container ">
            <div class="row ">
                <div class="col-lg-3 ">
                    <div class="footer-logo ">
                        <a href="<?php echo e(url('/')); ?>"><img src="<?php echo ( config('site.footer_logo') && File::exists(public_path('uploads/'.config('site.footer_logo'))) ) ? asset('/uploads/'.config('site.footer_logo')) : asset('/frontend/img/footer-logo.png'); ?>" alt=""></a>
                        <p><?php echo config('site.footer1_content'); ?></p>
                    </div>
                </div>
                <div class="col-lg-6 ">
                    <ul class="footer-menu ">
                      <?php $__currentLoopData = $footer_menu_page; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php
                      $slug = $menu->slug;
                      if ($menu->menu_link>0) {
                        $slug = get_field_value('pages',"slug",'id',$menu->menu_link);
                      }
                      $slug = ($menu->id==1) ? '' : $slug ;
                      ?>
                      <li><a href="<?php echo e(url('/'.$slug)); ?>"><?php echo $menu->page_name; ?></a></li>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>

                    <div class=" ftr-address ">
                        <div class="icn "><img src="<?php echo e(asset('/frontend/img/ftr-address.png')); ?>" alt=" "></div>
                        <div class="txt ">
                            <p><?php echo config('site.address_title'); ?></p>
                            <p><?php echo config('site.address'); ?></p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 ">
                    <?php if(config('site.social_title')): ?><h6><?php echo config('site.social_title'); ?></h6><?php endif; ?>
                    <ul class="ftr-social ">
                      <?php if(config('site.facebook_link')): ?><li><a href="<?php echo config('site.facebook_link'); ?>" target="_blank"><div class="icn "><img src="<?php echo e(asset('/frontend/img/fb.png')); ?>" alt=" "> </div><p>facebook Id</p></a></li><?php endif; ?>
                      <?php if(config('site.instagram_link')): ?><li><a href="<?php echo config('site.instagram_link'); ?>" target="_blank"><div class="icn "><img src="<?php echo e(asset('/frontend/img/instragram_icon.png')); ?>" alt=" "> </div><p>instagram Id</p></a></li><?php endif; ?>
                      <?php if(config('site.twitter_link')): ?><li><a href="<?php echo config('site.twitter_link'); ?>" target="_blank"><div class="icn "><img src="<?php echo e(asset('/frontend/img/twitter_icon.png')); ?>" alt=" "> </div><p>twitter Id</p></a></li><?php endif; ?>
                      <?php if(config('site.linkedin_link')): ?><li><a href="<?php echo config('site.linkedin_link'); ?>" target="_blank"><div class="icn "><img src="<?php echo e(asset('/frontend/img/linkedin_icon.png')); ?>" alt=" "> </div><p>linkedin Id</p></a></li><?php endif; ?>
                        <li>
                            <a href="mailto:<?php echo config('site.email'); ?>">
                                <div class="icn "><img src="<?php echo e(asset('/frontend/img/email_icon.png')); ?>" alt=" "> </div>
                                <p><?php echo config('site.email'); ?></p>
                            </a>
                        </li>
                        <li>
                            <a href="tel:<?php echo preg_replace('/\D+/', '', config('site.phone')); ?>">
                                <div class="icn "><img src="<?php echo e(asset('/frontend/img/telephone_icon.png')); ?>" alt=" "> </div>
                                <p><?php echo config('site.phone'); ?></p>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="line "></div>
        </div>
    </div>
    <div class="arrowlft" ><i class="fa fa-arrow-circle-right"></i></div>
    <div class="popup-hldr fadeInLeft" data-wow-deuration="2s " data-wow-delay=".2s ">
        <div class="hldr"><h2>LOREM IPSUM DOLOR SITTETU</h2>
        <p>Lorem ipsum dolor sit amet, consectetuer adiscing elit, sed diam </p>
        <a href="javascript:void(0)" class="book">Book Now</a>
        <div class="close"><a href="javascript:void(0)"><i class="fa fa-times-circle"></i></a></div></div>
    </div>
    <script src="<?php echo e(asset('/frontend/js/jquery.min.js')); ?>">
    </script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="<?php echo e(asset('/frontend/js/custom.js')); ?>"></script>
    <script src="<?php echo e(asset('/frontend/js/wow.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/frontend/js/custom.js')); ?>"></script>
    <script src="<?php echo e(asset('/frontend/js/owl.carousel.js')); ?>"></script>


<div id="loading"><div class="loader"></div></div>

<!-- Alert Message Modal -->
<div class="modal" id="alertMessage" tabindex="-1" role="dialog" aria-labelledby="alertMessage" aria-hidden="true">
  <div class="modal-dialog  modal-dialog-centered" role="document">
    <div class="modal-content" style="max-width: 610px;">
      <div class="modal-body">
        <h5 class="modal-title title">Alert</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"></button>
        <div class="clearfix"></div>
        <div class="content"></div>
      </div>
    </div>
  </div>
</div>

<!-- Confirm Modal -->
<div id="deleteModal" class="modal" role="dialog">
  <div class="modal-dialog  modal-dialog-centered">
    <div class="modal-content">      
      <div class="modal-body">
        <h4 class="title"></h4>   
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"></button>
        <div class="clearfix"></div>
        <div class="content text-center">
          
        </div>
        <div class="modal-footer">
          <button class="btn btnTxt" data-dismiss="modal" aria-hidden="true">Cancel</button>
          <a class="btn" id="dataConfirmOK">Delete</a>
        </div>
      </div>      
    </div>
  </div>
</div>



<!-- Validation JS -->
<script src="<?php echo e(asset("/frontend/js/jquery.validationEngine.min.js")); ?>"></script>
<script src="<?php echo e(asset("/frontend/js/jquery.validationEngine-en.js")); ?>"></script>
<script>
  function customvalidation()
  {
    jQuery(".customvalidation").validationEngine('attach', {
      relative: true,
      overflownDIV:"#divOverflown",
      promptPosition:"topLeft"
    });
    jQuery(".customvalidation_bottom").validationEngine('attach', {
      relative: true,
      overflownDIV:"#divOverflown",
      promptPosition:"bottomLeft"
    });
  }
  customvalidation();

  var confirmModal = function(){
    $('#deleteModal .modal-body .content').html($(this).attr('data-confirm'));
    $('#deleteModal .title').html($(this).attr('data-title'));
    $('#dataConfirmOK').attr('href',$(this).attr('href'));
    $('#deleteModal').modal('show');
    return false;
  };

  $('body').on('click', 'a[data-confirm]', confirmModal);
//alert('eee');
// $("#alertMessage").modal('show');
</script>

<?php if(Session::has('message')): ?> 
<script>
 $(window).on('load', function () {

    $("#alertMessage .title").hide();
    $("#alertMessage .content").empty().html('<?php echo Session::get('message'); ?>');
    // $("#alertMessage").fadeIn();
    $("#alertMessage").modal('show');
    setTimeout(function() { $('#alertMessage').fadeOut(); }, <?php echo config('site.message_show_time')*1000; ?>);
  });
</script>
<?php endif; ?>


<?php echo $__env->yieldContent('more-scripts'); ?>

</body>
</html><?php /**PATH G:\xampp\htdocs\globalization\resources\views/frontend/footer.blade.php ENDPATH**/ ?>