<?php echo $__env->make('frontend.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php
$location = get_fields_value_where('pages',"page_template=3",'id','desc');

?>
<?php $__currentLoopData = $location; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lval): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php

$location_extra = get_fields_value_where('pages_extra',"page_id=".$lval->id,'id','desc');
?>
<?php $__currentLoopData = $location_extra; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <?php if($val->type==1): ?>
<!------ banner area start -------->
<div class="subpagr_banner" style="background-image:url(<?php echo e(asset('/uploads/'.$val->image)); ?>);">
  <div class="container">
    <h1><?php echo $val->title; ?></h1>
    <nav class="breadcrumb"> <a class="breadcrumb-item" href="<?php echo e(url('/')); ?>">home</a> <a class="breadcrumb-item" href="<?php echo e(url('/')); ?>/<?php echo $lval->slug; ?>"><?php echo $page->page_title; ?></a> <span class="breadcrumb-item active"><?php echo $val->title; ?></span> </nav>
  </div>
</div>
 <?php endif; ?>
 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<!------ banner area stop --------> 

<!------ main area start -------->

<div class="mainarea p-80">
  <div class="location_img_area">
    <div class="container">
      <div class="row mb-4">
        <div class="col-lg-12">
          <?php $__currentLoopData = $extra_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($val->type==2 && ($val->image)): ?>
          <div class="location_big_img"> <img src="<?php echo e(asset('/uploads/'.$val->image)); ?>" alt="location image" title="" /> </div>
           <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
       
      </div>
      <div class="location_heading">
        <?php $__currentLoopData = $extra_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($val->type==2 && ($val->title)): ?>
        <h2><?php echo $val->title; ?></h2>
         <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     <!--   <h3><img src="<?php echo e(asset('frontend')); ?>/images/location-icon.png" alt="location icon" title="" class="location-icon" /><strong>Location:</strong> <?php $__currentLoopData = $extra_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>-->
     <!--       <?php if($val->type==2 && ($val->body)): ?>-->
     <!--<?php echo e(strip_tags($val->body)); ?>-->
     <!--   <?php endif; ?>-->
     <!--       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></h3>-->
      </div>
      <div class="row">
        <div class="col-lg-12">
          <div class="overview_area box_shadow">
            <h3>Description:</h3>
            <?php $__currentLoopData = $extra_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($val->type==2 && ($val->body)): ?>
        <?php echo $val->body; ?>

         <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
         
        </div>

        
      </div>
    </div>
  </div>
</div>
<!------ main area stop --------> 

<?php echo $__env->make('frontend.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/webtech7/public_html/project/sandalwood/resources/views/frontend/pages/service_details.blade.php ENDPATH**/ ?>