<?php echo $__env->make('frontend.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('frontend.pages.service-top', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__currentLoopData = $extra_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <?php if($val->type==2): ?>
  <div id="overviews" class="section">
    <div class="container">

      <div class="row align-items-center">
        <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 wow fadeIn">
          <div class="img">
            <?php if($val->image && File::exists(public_path('uploads/'.$val->image)) ): ?><img src="<?php echo e(asset('/uploads/'.$val->image)); ?>" alt="" class="img-fluid img-rounded"><?php endif; ?>
          </div>
        </div>
        <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 wow fadeInRight">
          <div class="message-box">
            <h3 class="title"><?php echo $val->title; ?></h3>
            <div class="lg-txt-div"><?php echo $val->body; ?></div>

            <?php if($val->btn_url): ?><a href="<?php echo $val->btn_url; ?>" class="hover-btn-new mt-4"><span><?php echo $val->btn_text?$val->btn_text:'Contact Us'; ?> &nbsp; <span><img src="<?php echo e(asset('/frontend/images/arrow.svg')); ?>" /></span></a><?php endif; ?>
            </div><!-- end messagebox -->
          </div>
        </div>
      </div>
    </div>
  <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<div id="meet" class="section">
  <div class="container">

<?php
$section_4_title = '';
$section_4_body = '';
$section_6_title = '';
$section_6_body = '';
$section_8_title='';
$section_8_image = '';
$section_8_btn_text='';
$section_8_btn_url='';
$section_9_title = '';
$section_9_body = '';
$section_11_title = '';
$section_13_title = '';
$section_13_btn_text='';
$section_14_title = '';
$section_14_body = '';
$section_14_image = '';
$section_15_title='';
$section_15_image = '';
$section_15_btn_text='';
$section_15_btn_url='';
?>
<?php $__currentLoopData = $extra_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <?php if($val->type==3): ?>
  <div class="row align-items-center">
    <div class="col-xl-4 col-lg-4 col-md-12 col-sm-12 wow fadeIn">
      <div class="meet-img">
        <?php if($val->image && File::exists(public_path('uploads/'.$val->image)) ): ?><img src="<?php echo e(asset('/uploads/'.$val->image)); ?>" alt="" class="img-fluid img-rounded"><?php endif; ?>
      </div>
    </div>
    <div class="col-xl-8 col-lg-8 col-md-12 col-sm-12 wow fadeInRight">
      <div class="message-box wt">
        <h4 class="title"><?php echo $val->title; ?></h4>
        <div class="lg-txt-div"><?php echo $val->body; ?></div>
        <?php if($val->btn_url): ?><a href="<?php echo $val->btn_url; ?>" class="hover-btn-new mt-4"><span><?php echo $val->btn_text?$val->btn_text:'Contact Us'; ?> &nbsp; <span><img src="<?php echo e(asset('/frontend/images/arrow.svg')); ?>" /></span></a><?php endif; ?>
        </div><!-- end messagebox -->
      </div>
    </div>
  <?php endif; ?>
      <?php
      if ($val->type==4) {
        $section_4_title = $val->title;
        $section_4_body = $val->body;
      }
      if ($val->type==6) {
        $section_6_title = $val->title;
        $section_6_body = $val->body;
      }
      if ($val->type==8) {
        $section_8_title = $val->title;
        $section_8_image = ($val->image && File::exists(public_path('uploads/'.$val->image)))?asset('/uploads/'.$val->image):'';
        $section_8_btn_text = $val->btn_text;
        $section_8_btn_url = $val->btn_url;
      }
      if ($val->type==9) {
        $section_9_title = $val->title;
        $section_9_body = $val->body;
      }
      if ($val->type==11) {
        $section_11_title = $val->title;
      }
      if ($val->type==13) {
        $section_13_title = $val->title;
        $section_13_btn_text = $val->btn_text;
      }
      if ($val->type==14) {
        $section_14_title = $val->title;
        $section_14_body = $val->body;
        $section_14_image = ($val->image && File::exists(public_path('uploads/'.$val->image)))?asset('/uploads/'.$val->image):'';
      }
      if ($val->type==15) {
        $section_15_title = $val->title;
        $section_15_image = ($val->image && File::exists(public_path('uploads/'.$val->image)))?asset('/uploads/'.$val->image):'';
        $section_15_btn_text = $val->btn_text;
        $section_15_btn_url = $val->btn_url;
      }
      ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
</div>

<div class="section" id="why">
  <div class="container">
    <div class="section-title row text-center  wow fadeIn">
      <div class="col-md-12">
        <h3 class="title text-center"><?php echo $section_4_title; ?></h3>
        <div class="lg-txt-div"><?php echo $section_4_body; ?></div>
      </div>
    </div>
    <div class="row">
      <?php $count=0; ?>
<?php $__currentLoopData = $extra_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <?php if($val->type==5): ?>
    <?php $count++;
    if ($count==1) {
        $fade_class='fadeInLeft';
    }elseif ($count==2) {
        $fade_class='fadeIn';
    }elseif ($count==3) {
        $fade_class='fadeInRight';
        $count=0;
    }else {
        $fade_class='';
    }
    ?>
      <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12  wow <?php echo e($fade_class); ?>">
        <div class="card wt">
          <div class="card-body">
            <div class="row">
              <div class="col-lg-2 col-md-2">
                <div class="bg-box"><?php echo $val->sub_title; ?></div>
              </div>
              <div class="col-lg-10 col-md-10">
                <h3 class="card-title"><?php echo $val->title; ?></h3>
              </div>
              <div class="col-lg-12 ">
                <div class="pt-5"><?php echo $val->body; ?></div>
              </div>
            </div>
          </div>
        </div>
      </div>
  <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>
</div>
<div class="section" id="iot-s">
  <div class="container">
    <div class="section-title row text-center  wow fadeIn">
      <div class="col-md-12">
        <h3 class="title text-center text-white"><?php echo $section_6_title; ?></h3>
        <div class="lg-txt-div text-white"><?php echo $section_6_body; ?></div>
      </div>
    </div>
  </div>
</div>
<div class="container" id="test-s">
  <div class="row">
    <?php $count=0; ?>
<?php $__currentLoopData = $extra_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <?php if($val->type==7 && $val->title): ?>
    <?php $count++;
    $fade_class = ($count%2==0) ? 'fadeInRight' : 'fadeInLeft' ;
    ?>
    <div class="col-xl-6 col-lg-6 p-0 col-md-6 col-sm-12 wow <?php echo e($fade_class); ?>">
      <div class="card">
        <div class="card-body">
          <h3 class="card-title"><span><img src="<?php echo e(asset('/frontend/images/circle.svg')); ?>"></span><?php echo $val->title; ?></h3>
          <div class="pt-5"><?php echo $val->body; ?></div>
        </div>
      </div>
    </div>
  <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  </div>
</div>


<div class="section about">
  <div class="col-xl-10 offset-md-1 col-lg-10 p-0 col-md-12 col-sm-12 align-items-center  wow fadeIn">
    <div class="card no-radius bg-triangle"
    style="background-image:url('<?php echo $section_8_image; ?>');background-repeat: no-repeat;">

    <div class="about-img">
      <h3><?php echo $section_8_title; ?></h3>
      <div class="btn-wrapper">
        <?php if($section_8_btn_url): ?><a href="<?php echo $section_8_btn_url; ?>" class="hover-btn-new mt-4"><span><?php echo $section_8_btn_text?$section_8_btn_text:'Contact Us'; ?> &nbsp; </a><?php endif; ?>
      </div>
    </div>


  </div>
</div>
</div>
<div class="container">
  <div class="section-title row text-center" data-aos="fade-up">
    <div class="col-md-12">

      <h3 class="title text-center"><?php echo $section_9_title; ?></h3>
      <?php echo $section_9_body; ?>

      <div class="lg-txt-div"><?php echo $section_9_body; ?></div>

    </div>
  </div>
</div>
<div id="service" class="section pf-min">
  <div class="container">

    <div class="row align-items-center">
      <?php $count=0; ?>
      <?php $__currentLoopData = $extra_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($val->type==10): ?>
          <?php $count++;
          if ($count==1) {
              $aos='fade-right';
              $card='wt';
          }elseif ($count==2) {
              $aos='fade-up';
              $card='';
          }elseif ($count==3) {
              $aos='fade-left';
              $card='wt';
              $count=0;
          }else {
              $aos='';
              $width='';
          }
          ?>
      <div class="col-xl-4 col-lg-4 p-0 col-md-6 col-sm-12 aos-init aos-animate" data-aos="<?php echo $aos; ?>">
        <div class="card <?php echo $card; ?>">
          <div class="card-body">
            <div class="row">
              <div class="col-lg-12 col-md-12">
                <div class="icon">
                  <?php if($val->image && File::exists(public_path('uploads/'.$val->image)) ): ?><img src="<?php echo e(asset('/uploads/'.$val->image)); ?>"><?php endif; ?>
                </div>
              </div>
              <div class="col-lg-12 col-md-12">
                <h3 class="card-title text-center"><?php echo $val->title; ?></h3>
              </div>
              <div class="col-lg-12">
                <div class="pt-5"><?php echo $val->body; ?></div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>
</div>
<div class="section iot-slider">
  <div class="col-md-10 offset-md-1 wow fadeIn">
    <h3 class="title mb-10 text-center"><?php echo $section_11_title; ?></h3>
    <br>
  </div>
  <!-- TESTIMONIALS -->
  <section class="testimonials">
    <div class="container">

      <div class="row  align-items-center">
        <div class="col-sm-12">
          <div id="customers-testimonials" class="owl-carousel"> 
      <?php $count=0; ?>
      <?php $__currentLoopData = $extra_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($val->type==12): ?>
          <?php $count++;
          if ($count==1) {
              $class_div='';
          }else {
              $class_div='align-items-center';
          }
          ?>
            <div class="item <?php echo e($class_div); ?>">
              <div class="shadow-effect">
                <h3 class="card-title"><?php echo $val->title; ?></h3>
                <?php echo $val->body; ?>  
              </div>
            </div>
      <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          </div>
        </div>
      </div>
    </div>
  </section> 
</div>


<div class="section" id="contact_home">
  <div class="container">
    <div class="get-intouch  align-items-center  wow fadeIn">
            <?php if($errors->any()): ?>   
            <div class="alert alert-danger alert-dismissible">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            <h4><i class="icon fa fa-ban"></i> Alert!</h4>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo e($error); ?><br>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php endif; ?>
                <form method="POST" action="<?php echo e(url('contact')); ?>" class="customvalidation_bottom">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="action" value="contact_home">
      <div class="row">
        <div class="col-lg-2 col-md-12 col-sm-6 col-xs-12">
          <h3><?php echo $section_13_title; ?></h3>
        </div>
        <div class="col-lg-2 pt-2 col-md-6 col-sm-6 col-xs-12">
          <input type="text" class="form-control" placeholder="Your Name*" data-validation-engine="validate[required]" name="name" value="<?php echo e(old('name')); ?>">
        </div>
        <div class="col-lg-2 pt-2 col-md-6 col-sm-6 col-xs-12">
          <input type="text" class="form-control" placeholder="Email ID*" data-validation-engine="validate[required,custom[email]]" name="email" value="<?php echo e(old('email')); ?>">
        </div>
        <div class="col-lg-2 pt-2 col-md-6 col-sm-6 col-xs-12">
          <input type="text" class="form-control" placeholder="Phone Number" name="phone" value="<?php echo e(old('phone')); ?>">
        </div>
        <div class="col-lg-2 pt-2 col-md-6 col-sm-6 col-xs-12">
          <select class="form-control select2" name="service" data-validation-engine="validate[required]">
              <option value="">Select Service</option>
          <?php
          $services = get_fields_value_where('pages',"posttype='service'",'menu_order','asc');// and parent_id='0'
          foreach ($services as $key => $value) {
          ?>
            <option value="<?php echo $value->page_name; ?>" <?php echo old('service')==$value->page_name?'selected':''; ?>><?php echo $value->page_name; ?></option>
          <?php
          }
          ?>
          </select>
        </div>
        <div class="col-lg-2 col-md-12 psy-2 col-sm-6 col-xs-12">
          <button class="hover-btn-new"> <?php echo $section_13_btn_text?$section_13_btn_text:'Submit'; ?> </button>
        </div>
      </div>
    </div>
  </div>
</div>

<div id="overviews" class="section">
  <div class="container">
    <div class="row align-items-center">
      <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 wow fadeInLeft">
        <div class="message-box">
          <h3 class="title"> <?php echo $section_14_title; ?></h3>
          <div class="lg-txt-div"><?php echo $section_14_body; ?></div>
        </div><!-- end messagebox -->
      </div>
      <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 wow fadeInRight">
        <div class="img">
          <?php if($section_14_image): ?><img src="<?php echo $section_14_image; ?>" alt="" class="img-fluid img-rounded"><?php endif; ?>
        </div>
      </div>
    </div>
  </div>
</div>

<div class="section about">
  <div class="col-xl-10 offset-md-1 col-lg-10 p-0 col-md-12 col-sm-12 align-items-center  wow fadeIn">
    <div class="card no-radius"
    style="background-image:url('<?php echo $section_15_image; ?>');background-repeat: no-repeat;">
      <div class="about-img ">
        <h3><?php echo $section_15_title; ?></h3>
        <div class="btn-wrapper">
          <?php if($section_15_btn_url): ?><a href="<?php echo $section_15_btn_url; ?>" class="hover-btn-new mt-4"><span><?php echo $section_15_btn_text?$section_15_btn_text:'Contact Us'; ?> &nbsp; </a><?php endif; ?>
        </div>
      </div>
    </div>
  </div>
</div>



<?php $__env->startSection('more-scripts'); ?>

<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/2.2.2/jquery.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.1.1/owl.carousel.min.js"></script>
<script>
    jQuery(document).ready(function($) {
               "use strict";
               //  TESTIMONIALS CAROUSEL HOOK
               $('#customers-testimonials').owlCarousel({
                   loop: true,
                   center: true,
                   items: 3,
                   margin: 0,
                   autoplay: true,
                   dots:true,
                   autoplayTimeout: 8500,
                   smartSpeed: 450,
                   responsive: {
                     0: {
                       items: 1
                     },
                     768: {
                       items: 2
                     },
                     1170: {
                       items: 3
                     }
                   }
               });
           });
</script>
<script type="text/javascript">
$(window).ready (function () {
});
</script>
<?php if(old('action')=='contact_home'): ?> 
<script>
  $(document).ready(function() {
    $('html,body').animate({
        scrollTop: $("#<?php echo e(old('action')); ?>").offset().top-200
    }, 700);
  });
</script>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\webtechnomind\infotree\resources\views/frontend/pages/service1.blade.php ENDPATH**/ ?>