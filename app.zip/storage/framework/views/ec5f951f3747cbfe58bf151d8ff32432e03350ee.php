<?php
print_r($content)
?><?php /**PATH E:\wamp64\www\webtechnomind\infotree\resources\views/mail.blade.php ENDPATH**/ ?>