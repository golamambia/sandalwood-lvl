 
<?php echo $__env->make('frontend.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

 <!------- inner banner area start ------->
  <?php $__currentLoopData = $extra_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

      <?php if($val->type==1): ?>
    <section class="inner_banner_area" style="background-image: url(<?php echo e(asset('/uploads/'.$val->image)); ?>);">
        <div class="container">
            <div class="inner_banner_contain">
                <h1><?php echo $val->sub_title; ?><strong><?php echo $val->title; ?></strong></h1>
                <?php echo $val->body; ?>

                <?php if($val->btn_url): ?><a href="<?php echo $val->btn_url; ?>" class="btn btn-custom mt-4"><?php echo $val->btn_text?$val->btn_text:'contact Us'; ?></a><?php endif; ?>
            </div>
        </div>
 </section>
    <?php endif; ?>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<div class="mainbox p-8">
    <?php $__currentLoopData = $extra_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

      <?php if($val->type==2): ?>
  <div class="innerabout_us globaltop">
    <div class="container">
      <div class="row">
        <div class="col-lg-6 col-md-6">
          <div class="innerabout_thumble pt-0">
            <?php if($val->image && File::exists(public_path('uploads/'.$val->image)) ): ?>
            <img src="<?php echo e(asset('/uploads/'.$val->image)); ?>" alt="#"><?php endif; ?>
          </div>
        </div>
        <div class="col-lg-6 col-md-6">
          <div class="innerabout_contantbox p-3">
            <h3><?php echo $val->title; ?><br> 
              <strong><?php echo $val->sub_title; ?></strong></h3>
            <?php echo $val->body; ?>

          </div>
        </div>
      </div>
    </div>
  </div>
      <?php endif; ?>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


  <div class="global_reacharea p-8 pb-0">
    <div class="container">
      <div class="search_area d-flex justify-content-between align-items-center">
        <?php $__currentLoopData = $extra_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <?php if($val->type==3): ?>
         <h5><?php echo $val->title; ?></h5>
           <?php endif; ?>

          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


          <select class="form-control">
            <option>Which regions do you need help in?</option>
            <?php $__currentLoopData = $country; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option><?php echo $val->country_name; ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <!-- <option>America</option>
            <option>Asia</option>
            <option>Europe</option>
            <option>Oceania</option> -->
          </select>
       </div>

      <div class="global_listbox">
       <div class="row row-8">
        <?php $__currentLoopData = $country; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <div class="col-lg-3 col-md-3 col-sm-4 col-6">
           <div class="citybox">
            <a href="#">
             <div class="city_thumble d-flex">
               <?php if($val->image && File::exists(public_path('uploads/'.$val->image)) ): ?>
                <img src="<?php echo e(asset('/uploads/'.$val->image)); ?>" alt=""><?php endif; ?>
               <div class="overname">
                 <?php echo $val->country_name; ?>

               </div>
             </div>
             </a>
           </div>
         </div>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
       </div>
     </div>
    </div>
  </div>

</div>
<?php echo $__env->make('frontend.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/webtech7/public_html/project/globalization/resources/views/frontend/pages/our_global_reach.blade.php ENDPATH**/ ?>