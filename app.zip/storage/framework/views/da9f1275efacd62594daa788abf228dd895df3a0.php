<?php echo $__env->make('frontend.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__currentLoopData = $extra_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($val->type==1 && $val->image && File::exists(public_path('uploads/'.$val->image))): ?>
    <div class=" service-banner " style="background: url(<?php echo e(asset('/uploads/'.$val->image)); ?>) no-repeat center  ">
        <div class="container">
            <div class="txt">
              <?php $__currentLoopData = $extra_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <?php if($val->type==1 && $val->title): ?>
                <h1><?php echo $val->title; ?></h1><?php endif; ?>
                <?php if($val->type==1 && $val->sub_title): ?>
                <p><?php echo $val->sub_title; ?></p>
                <?php endif; ?>
               
            </div>
            <div class="bottom-txt">
              <?php if($val->type==1 && $val->body): ?>
              <?php echo $val->body; ?>

              <?php endif; ?>
              </div>
              
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
     <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <div class="services">
      <!-- <?php
    // echo $page->page_title;
//print_r($page);
      ?> -->
        <div class="container">
            <h2><?php echo e($page->page_title); ?></h2>
            <ul class="row">
               <?php $__currentLoopData = $extra_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <?php if($val->type==2 && $val->image && File::exists(public_path('uploads/'.$val->image))): ?>
                <li class="col-lg-4 col-md-4 wow fadeInUp" data-wow-deuration="2s " data-wow-delay=".2s ">
                    <div class="icon">
                        <img src="<?php echo e(asset('/uploads/'.$val->image)); ?>" alt="">
                    </div>
                    <div class="txt">
                        <h3><?php echo $val->title; ?></h3>
                        <h4><?php echo $val->sub_title; ?></h4>
                       <?php echo $val->body; ?>

                    </div>
                </li>
                 <?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    </div>
    <div class="how-do">
        <div class="container">
            <h3>How do we Work?</h3>
            <p>Fill the form below and reach us with your idea/ question/ suggestion</p>
            <ul class="how-do-list">
                <li>
                    <div class="icon-hldr justify-content-center d-flex flex-column align-items-center">
                        <span>1</span>
                        <img src="<?php echo e(asset('frontend')); ?>/img/introduction_icon.png" alt="">
                    </div>
                    <h5>INTRODUCTION
                        MEETING</h5>
                </li>
                <li>
                    <div class="icon-hldr justify-content-center d-flex flex-column align-items-center">
                        <img src="<?php echo e(asset('frontend')); ?>/img/preparation_icon.png" alt="">
                        <span>2</span>
                    </div>
                    <h5>PREPARATION OF
                        TECHNICAL SPECIFICATION</h5>
                </li>
                <li>
                    <div class="icon-hldr justify-content-center d-flex flex-column align-items-center">
                        <img src="<?php echo e(asset('frontend')); ?>/img/project_estimation_icon.png" alt="">
                        <span>3</span>
                    </div>
                    <h5>PROJECT
                        ESTIMATION</h5>
                </li>
                <li>
                    <div class="icon-hldr justify-content-center d-flex flex-column align-items-center">
                        <img src="<?php echo e(asset('frontend')); ?>/img/project_plan_icon.png" alt="">
                        <span>4</span>
                    </div>
                    <h5>PROJECT
                        PLAN</h5>
                </li>
                <li>
                    <div class="icon-hldr justify-content-center d-flex flex-column align-items-center">
                        <img src="<?php echo e(asset('frontend')); ?>/img/ui_ux_design_icon.png" alt="">
                        <span>5</span>
                    </div>
                    <h5>UI/ UX
                        DESIGN</h5>
                </li>
                <li>
                    <div class="icon-hldr justify-content-center d-flex flex-column align-items-center">
                        <img src="<?php echo e(asset('frontend')); ?>/img/development_icon.png" alt="">
                        <span>6</span>
                    </div>
                    <h5>DEVELOPMENT</h5>
                </li>
                <li>
                    <div class="icon-hldr justify-content-center d-flex flex-column align-items-center">
                        <img src="<?php echo e(asset('frontend')); ?>/img/qa_qc_icon.png" alt="">
                        <span>7</span>
                    </div>
                    <h5>QA/ QC
                        TESTING</h5>
                </li>
                <li>
                    <div class="icon-hldr justify-content-center d-flex flex-column align-items-center">
                        <img src="<?php echo e(asset('frontend')); ?>/img/launching_icon.png" alt="">
                        <span>8</span>
                    </div>
                    <h5>LAUNCHING</h5>
                </li>
                <li>
                    <div class="icon-hldr justify-content-center d-flex flex-column align-items-center">
                        <img src="<?php echo e(asset('frontend')); ?>/img/support_icon.png" alt="">
                        <span>9</span>
                    </div>
                    <h5>SUPPORT</h5>
                </li>
            </ul>
            <div class="clear-fix"></div>
            <a href="#" class="view-mr">View More</a>
        </div>
    </div>
    <div class="service-blue">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 wow fadeInLeft " data-wow-deuration="2s " data-wow-delay=".2s ">
                    <h2>HAVE <br>
                        AN <br>
                        IDEA?</h2>
                        <a href="#" class="click">CLICK HERE</a>
                </div>
                <div class="col-lg-8 wow fadeInRight " data-wow-deuration="2s " data-wow-delay=".2s ">
                    <div class="hldr">
                    <form>
                        <div class="form-group ">
                            <label>Full Name</label>
                            <input type="text " class="form-control " placeholder="Lorem ipsum dolor mod tincidunt ">
                        </div>
                        <div class="form-group ">
                            <label>Email Id</label>
                            <input type="text " class="form-control " placeholder="Lorem ipsum dolor mod tincidunt ">
                        </div>
                        <div class="form-group ">
                            <label>Type your Message</label>
                            <textarea class="form-control " placeholder="Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euis- mod tincidunt ut laoreet dolore magna ali- "></textarea>
                        </div>
                        <div class="form-group ">
                            <label class="check "><input type="checkbox"><span class="checkmark "></span> Need NDA?</label>
                        </div>
                        <div class="form-group "><input type="submit" value="Send "></div>
                    </form>
                </div>
                </div>
            </div>
        </div>
    </div>


<?php $__env->startSection('more-scripts'); ?>

<script type="text/javascript">
$(window).ready (function () {
});
</script>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('frontend.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp\htdocs\dopadoxnw\resources\views/frontend/pages/service.blade.php ENDPATH**/ ?>