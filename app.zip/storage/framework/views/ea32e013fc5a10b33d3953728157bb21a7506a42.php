<?php echo $__env->make('frontend.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php
$location_type = get_fields_value_where('pages',"posttype='location'",'id','desc');
?>
<!------ banner area start -------->

<?php $__currentLoopData = $extra_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <?php if($val->type==1): ?>
<!------ banner area start -------->
<div class="subpagr_banner" style="background-image:url(<?php echo e(asset('frontend')); ?>/images/subbanner1.jpg);">
  <div class="container">
     <?php if($val->title): ?><h1><?php echo $val->title; ?></h1><?php endif; ?>
    
    <nav class="breadcrumb"> <a class="breadcrumb-item" href="<?php echo e(url('/')); ?>">home</a> <span class="breadcrumb-item active"><?php echo e($page->page_title); ?></span> </nav>
  </div>
</div>
<!------ banner area stop --------> 
 <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<!------ banner area stop --------> 

<!------ main area start -------->

<div class="mainarea p-80">
  <div class="employment_area locarea">
    <div class="container">
      <?php if($location_type->count() > 0): ?>
 <?php $__currentLoopData = $location_type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lt_val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
 <?php
$extra_data = get_fields_value_where('pages_extra',"page_id=".$lt_val->id,'id','desc');
?>

    <div class="locationarea mb-5">
      <div class="row">
        <div class="col-lg-5 pr-5 leftbox">
          <div class="locimg">
            <?php $__currentLoopData = $extra_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($val->type==1 && ($val->image)): ?>
            <img src="<?php echo e(asset('/uploads/'.$val->image)); ?>" alt=" ">
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
        </div>
       <div class="col-lg-7 rightbox">
         <h2>
        <?php $__currentLoopData = $extra_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($val->type==1 && ($val->title)): ?>
     <?php echo $val->title; ?>

        <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </h2>
         <div class="information_box"> <img src="<?php echo e(asset('frontend')); ?>/images/location-icon.png" alt="location icon" title="" class="img_icon">
              <h5>Location:</h5>
              <p><?php $__currentLoopData = $extra_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($val->type==2 && ($val->body)): ?>
     <?php echo e(strip_tags($val->body)); ?>

        <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></p>
            </div>
            <div class="information_box"> <img src="<?php echo e(asset('frontend')); ?>/images/phone-icon.png" alt="phone icon" title="" class="img_icon">
              <h5>Phone:</h5>
              <p> <?php $__currentLoopData = $extra_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($val->type==2 && ($val->title)): ?>
     <?php echo $val->title; ?>

        <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></p>
            </div>
            
            <a href="<?php echo e(url('/')); ?>/<?php echo $lt_val->slug; ?>" class="btn btn-primary">View more</a>
            
        </div> 
        
      </div>
      </div>
      
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php endif; ?>


    </div>
  </div>
</div>
<!------ main area stop --------> 

<?php echo $__env->make('frontend.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp\htdocs\sandalwood\resources\views/frontend/pages/location.blade.php ENDPATH**/ ?>