<?php echo $__env->make('frontend.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php $__currentLoopData = $extra_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <?php if($val->type==1): ?>
<!------ banner area start -------->
<div class="subpagr_banner" style="background-image:url(<?php echo e(asset('/uploads/'.$val->image)); ?>);">
  <div class="container">
     <?php if($val->title): ?><h1><?php echo $val->title; ?></h1><?php endif; ?>
    
    <nav class="breadcrumb"> <a class="breadcrumb-item" href="<?php echo e(url('/')); ?>">home</a> <span class="breadcrumb-item active"><?php echo e($page->page_title); ?></span> </nav>
  </div>
</div>
<!------ banner area stop --------> 
 <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<!------ main area start -------->


<div class="mainarea p-80">
  <div class="contact_page">
    <div class="container">
      <div class="contact_pagetop">
        <?php $__currentLoopData = $extra_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <?php if($val->type==2): ?>
        <h2><?php echo $val->title; ?></h2>
        <?php echo $val->body; ?>

        <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <div class="row">
             <?php $__currentLoopData = $extra_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <?php if($val->type==3): ?>
          <div class="col-lg-4 col-md-6">
            <div class="card">
              <h3><?php echo $val->title; ?></h3>
              <ul>
                  <?php if($val->sub_title): ?>
                <li><img src="<?php echo e(asset('frontend')); ?>/images/iconcontact1.png" alt="#"> <?php echo $val->sub_title; ?></li>
                <?php endif; ?>
                <?php if($val->body): ?>
                <li><img src="<?php echo e(asset('frontend')); ?>/images/iconcontact2.png" alt="#"> <?php echo e(strip_tags($val->body)); ?></li>
                <?php endif; ?>
                <?php if($val->btn_text): ?>
                <li><img src="<?php echo e(asset('frontend')); ?>/images/iconcontact3.png" alt="#"> <?php echo $val->btn_text; ?></li>
                <?php endif; ?>
                <?php if($val->btn_url): ?>
                <li><img src="<?php echo e(asset('frontend')); ?>/images/iconcontact4.png" alt="#"> <?php echo $val->btn_url; ?></li>
                <?php endif; ?>
              </ul>
              <a href="#" class="btn btn-outline-primary">View Google Maps</a>
            </div>
          </div>
    <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      </div>
      <div class="contact_pageformbox">
            <?php $__currentLoopData = $extra_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <?php if($val->type==4): ?>
        <h2><?php echo $val->title; ?></h2>
        <?php echo $val->body; ?>

        <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 <?php if($errors->any()): ?>   
            <div class="alert alert-danger alert-dismissible">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            <h4><i class="icon fa fa-ban"></i> Alert!</h4>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo e($error); ?><br>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php endif; ?>
        <form method="POST" action="<?php echo e(url('contact')); ?>" class="customvalidation">
           <?php echo csrf_field(); ?>
            <div class="row">
              <div class="col-lg-6">
                <div class="row row-8">
                  <div class="col-lg-6">
                    <div class="form-group">
                      <input type="text" class="form-control" placeholder="First Name*" data-validation-engine="validate[required]" name="fname">
                    </div>
                  </div>
                  <div class="col-lg-6">
                    <div class="form-group">
                      <input type="text" class="form-control" placeholder="Last Name*" data-validation-engine="validate[required]" name="lname">
                    </div>
                  </div>
                  <div class="col-lg-6">
                    <div class="form-group">
                      <input type="email" class="form-control"  placeholder="Email*" data-validation-engine="validate[required]" name="email">
                    </div>
                  </div>
                  <div class="col-lg-6">
                    <div class="form-group">
                      <input type="text" class="form-control numeric_input"placeholder="Phone*" data-validation-engine="validate[required]" name="phone" maxlength="10">
                    </div>
                  </div>
                   <div class="col-lg-6">
                    <div class="form-group">
                      <input type="text" class="form-control" placeholder="Address*" data-validation-engine="validate[required]" name="address">
                    </div>
                  </div>
                  <div class="col-lg-6">
                    <div class="form-group">
                      <input type="text" class="form-control"  placeholder="Zip Code*" data-validation-engine="validate[required]" name="zip">
                    </div>
                  </div>
                  <div class="col-lg-6">
                    <div class="form-group">
                       <input type="text" class="form-control" placeholder="State*" data-validation-engine="validate[required]" name="state">
                      <!--  <select class="select form-control" name="estados" id="estados">
                          <option value="selecione" disabled selected>Selet State</option>
                      </select> -->
                    </div>
                  </div>
                  <div class="col-lg-6">
                    <div class="form-group">
                       <input type="text" class="form-control" placeholder="City*" data-validation-engine="validate[required]" name="city">
                      <!-- <select class="select form-control" name="cidades" id="cidades">
                         <option value="selecione" disabled selected>Selet city</option>
                      </select> -->
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-lg-6">
             
                   <div class="form-group">
                     <input type="text" class="form-control" placeholder="Reason for Contact*" data-validation-engine="validate[required]" name="reason">
                     <!--  <select class=" form-control" name="" id="">
                         <option value="selecione" disabled selected>Reason for Contact</option>
                      </select> -->
                    </div>
                    <div class="form-group">
                      <textarea class=" form-control" placeholder="Message" name="message"></textarea>
                    </div>
                    <input type="submit" class="btn btn-primary" value="Submit now" name="">
              </div>
            </div>
          </form>
      </div>
    </div>
  </div>
</div>
<!------ main area stop --------> 

<?php echo $__env->make('frontend.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp\htdocs\sandalwood\resources\views/frontend/pages/contact_us.blade.php ENDPATH**/ ?>