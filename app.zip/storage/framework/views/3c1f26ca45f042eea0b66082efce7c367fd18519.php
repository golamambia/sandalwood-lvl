<?php echo $__env->make('frontend.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php $__currentLoopData = $extra_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <?php if($val->type==1): ?>
<!------- inner banner area start ------->
<section class="inner_banner_area" style="background-image: url(<?php echo e(asset('/uploads/'.$val->image)); ?>);">
  <div class="container">
    <div class="inner_banner_contain">
      <?php if($val->title): ?><h1><?php echo $val->title; ?></h1><?php endif; ?>
      <?php echo $val->body; ?>

      <?php if($val->btn_url): ?><a href="<?php echo $val->btn_url; ?>" class="btn btn-custom mt-4"><?php echo $val->btn_text?$val->btn_text:'contact Us'; ?></a><?php endif; ?>
    </div>
  </div>
</section>
  <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<div class="mainbox p-8">
<?php $__currentLoopData = $extra_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <?php if($val->type==2 && ($val->title || $val->body)): ?>
  <div class="about_single">
    <div class="container">
      <div class="text-center">
        <?php if($val->title): ?><h3><?php echo $val->title; ?></h3><?php endif; ?>
        <?php echo $val->body; ?>

      </div>
    </div>
  </div>
  <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  <div class="ourglobalreach_area p-8 pt-4">
    <div class="container">
      <div class="text-center">
<?php $__currentLoopData = $extra_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <?php if($val->type==3 && $val->title): ?>
        <h3><?php echo $val->title; ?></h3>
  <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       <div class="row howitworktotalbox servicesinner">
<?php $__currentLoopData = $extra_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <?php if($val->type==4 && ($val->title || $val->body)): ?>
         <div class="col-lg-4 col-md-6 col-sm-6 howitwork d-flex flex-wrap align-content-stretch">
           <div class="howitwork_box">
             <div class="howitwork_icon" style="background-image: url(<?php echo e(asset('/uploads/'.$val->image)); ?>);"></div>
             <?php if($val->title): ?><h4><?php echo $val->title; ?></h4><?php endif; ?>
             <?php echo $val->body; ?>

           </div>
         </div>
  <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       </div>
     </div>
   </div>
 </div>

 <div class="Whatwedo_area opportunityarea p-8 pt-0">
   <div class="container">
<?php $__currentLoopData = $extra_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <?php if($val->type==5 && ($val->title || $val->body)): ?>
    <div class="Whatwedo_box row">
     <div class="col-lg-6 col-md-6 Whatwedoimg d-flex flex-wrap align-content-stretch">
       <div class="Whatwedo_thumble d-flex">
         <?php if($val->image && File::exists(public_path('uploads/'.$val->image)) ): ?><img src="<?php echo e(asset('/uploads/'.$val->image)); ?>"> <?php endif; ?>
       </div>
     </div>
     <div class="col-lg-6 col-md-6 Whatwedocontent d-flex flex-wrap align-content-stretch align-items-center">
       <div class="Whatwedo_textbox">
        <?php if($val->title): ?><h3><?php echo $val->title; ?></h3><?php endif; ?>
        <?php if($val->sub_title): ?><h4><?php echo $val->sub_title; ?></h4><?php endif; ?>
        <?php echo $val->body; ?>

      </div>
    </div>
  </div>
  <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

     </div>
   </div>


   <div class="servicessigle_box pt-5">
    <div class="container">
<?php $__currentLoopData = $extra_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <?php if($val->type==6 && ($val->title || $val->body)): ?>
      <div class="text-center mb-5">
        <?php if($val->title): ?><h3><?php echo $val->title; ?></h3><?php endif; ?>
        <?php echo $val->body; ?>

      </div>
  <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__currentLoopData = $extra_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <?php if($val->type==7 && ($val->title || $val->body)): ?>
       <div class="media">
        <?php if($val->image && File::exists(public_path('uploads/'.$val->image)) ): ?><img class="align-self-start" src="<?php echo e(asset('/uploads/'.$val->image)); ?>" alt=""> <?php endif; ?>
        <div class="media-body">
          <?php if($val->title): ?><h5 class="mt-0"><?php echo $val->title; ?></h5><?php endif; ?>
          <?php echo $val->body; ?>

        </div>
      </div>
  <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__currentLoopData = $extra_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <?php if($val->type==8 && ($val->btn_url)): ?>
      <div class="text-center mt-3">
        <a href="<?php echo $val->btn_url; ?>" class="btn btn-custom mt-4"><?php echo $val->btn_text?$val->btn_text:'contact Us'; ?></a>
      </div>
  <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
  </div>
</div>






<?php $__env->startSection('more-scripts'); ?>

<script type="text/javascript">
$(window).ready (function () {
});
</script>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('frontend.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/webtech7/public_html/project/globalization/resources/views/frontend/pages/template2.blade.php ENDPATH**/ ?>