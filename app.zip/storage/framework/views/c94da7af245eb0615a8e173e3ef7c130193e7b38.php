<?php
$footer_menu = get_fields_value_where('pages',"(display_in='2' or display_in='3')",'menu_order','asc');
?>


<footer class="footer">
  <div class="container">
    <div class="row">
      <div class="col-lg-5 col-md-12 col-xs-12">
        <div class="widget clearfix">
          <div class="row">
            <div class="col-lg-7 col-md-6 col-xs-6">  
              <div class="ft-logo">
                <?php if(config('site.footer_logo') && File::exists(public_path('uploads/'.config('site.footer_logo')))): ?><img src="<?php echo e(asset('/uploads/'.config('site.footer_logo'))); ?>"><?php endif; ?>
                <?php if(config('site.footer1_title')): ?><p class="ft-tittle"><?php echo config('site.footer1_title'); ?></p><?php endif; ?>
              </div>
            </div>
            <div class="col-lg-5 col-md-6 col-xs-6">
              <div class="widget-title text-center">
                <?php if(config('site.footer2_title')): ?><h3><?php echo config('site.footer2_title'); ?></h3> <?php endif; ?>
                <?php if(config('site.footer2_sub_title')): ?><h3><?php echo config('site.footer2_sub_title'); ?></h3><?php endif; ?>
              </div>
            </div>
          </div>                      

          <div class="widget-title">
            <?php if(config('site.footer_map') && File::exists(public_path('uploads/'.config('site.footer_map')))): ?><img src="<?php echo e(asset('/uploads/'.config('site.footer_map'))); ?>"><?php endif; ?>
          </div><!-- end clearfix -->                     
        </div><!-- end col -->
      </div>
      <div class="col-lg-5 col-md-12">
        <div class="widget clearfix">
          <div class="row">
            <div class="col-lg-6 col-md-6  col-xs-6">
          <div class="widget-title">
            <?php if(config('site.footer3_title')): ?><h3><?php echo config('site.footer3_title'); ?></h3><?php endif; ?>
          </div>
              <ul class="footer-links">
                <?php          
                $counter = 0; 
                $footer_menu3 = '';
                $footer_menu4 = '';
                ?>
                <?php $__currentLoopData = $footer_menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                $counter++;
                $slug = $menu->slug;
                if ($menu->menu_link>0) {
                  $slug = get_field_value('pages',"slug",'id',$menu->menu_link);
                }
                if ($counter<7) {
                  $footer_menu3 .= '<li><a href="'.url('/'.$slug).'"> '.$menu->page_name.'</a></li>';
                }else{
                  $footer_menu4 .= '<li><a href="'.url('/'.$slug).'"> '.$menu->page_name.'</a></li>';
                }
                ?>                
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php echo $footer_menu3; ?>

              </ul>
            </div>
            <div class="col-lg-6 col-md-6 col-xs-6">
          <div class="widget-title">
            <?php if(config('site.footer4_title')): ?><?php endif; ?><h3><?php echo config('site.footer4_title'); ?> &nbsp;</h3>
          </div>
              <ul class="footer-links">
                <?php echo $footer_menu4; ?>

              </ul>
            </div>
          </div> 
        </div> 
      </div> 

      <div class="col-lg-2 col-md-4   col-xs-12" >
        <div class="widget clearfix">
          <div class="widget-title">
            <?php if(config('site.footer5_title')): ?><h3><?php echo config('site.footer5_title'); ?></h3><?php endif; ?>
          </div>

          <ul class="footer-links">
            <?php if(config('site.footer5_sub_title')): ?><li><b><?php echo config('site.footer5_sub_title'); ?></b></li><?php endif; ?>
            <li><?php echo nl2br(config('site.address')); ?></li>
            <li><b> Phone:</b></li>
            <li><?php echo config('site.phone'); ?></li>
            <li><b>Email:</b></li>
            <li><a href="mailto:<?php echo config('site.email'); ?>"><?php echo config('site.email'); ?></a>
            </ul><!-- end links -->
            <div class="footer-right">
              <ul class="footer-links-soi">
                <?php if(config('site.facebook_link')): ?><li><a href="<?php echo config('site.facebook_link'); ?>" target="_blank"><i class="fa fa-facebook"></i></a></li><?php endif; ?>
                <?php if(config('site.instagram_link')): ?><li><a href="<?php echo config('site.instagram_link'); ?>" target="_blank"><i class="fa fa-instagram"></i></a></li><?php endif; ?>
                <?php if(config('site.twitter_link')): ?><li><a href="<?php echo config('site.twitter_link'); ?>" target="_blank"><i class="fa fa-twitter"></i></a></li><?php endif; ?>
                <?php if(config('site.youtube_link')): ?><li><a href="<?php echo config('site.youtube_link'); ?>" target="_blank"><i class="fa fa-youtube"></i></a></li><?php endif; ?>
              </ul><!-- end links -->
            </div>
          </div><!-- end clearfix -->
        </div><!-- end col -->
        <!-- end row -->
      </div>
      <div class="row">
        <div class="col-md-4">
          <div class="footer-left">
            <p class="footer-company-name">All Rights Reserved. </p>
          </div>
        </div>
      </div> 
    </div><!-- end container -->
  </footer><!-- end footer -->


<div id="loading"><div class="loader"></div></div>

<!-- Alert Message Modal -->
<div class="modal" id="alertMessage" tabindex="-1" role="dialog" aria-labelledby="alertMessage" aria-hidden="true">
  <div class="modal-dialog  modal-dialog-centered" role="document">
    <div class="modal-content" style="max-width: 610px;">
      <div class="modal-body">
        <h5 class="modal-title title">Alert</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"></button>
        <div class="clearfix"></div>
        <div class="content"></div>
      </div>
    </div>
  </div>
</div>

<!-- Confirm Modal -->
<div id="deleteModal" class="modal" role="dialog">
  <div class="modal-dialog  modal-dialog-centered">
    <div class="modal-content">      
      <div class="modal-body">
        <h4 class="title"></h4>   
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"></button>
        <div class="clearfix"></div>
        <div class="content text-center">
          
        </div>
        <div class="modal-footer">
          <button class="btn btnTxt" data-dismiss="modal" aria-hidden="true">Cancel</button>
          <a class="btn" id="dataConfirmOK">Delete</a>
        </div>
      </div>      
    </div>
  </div>
</div>



<a href="#" id="scroll-to-top" class="dmtop global-radius"><span><img src="<?php echo asset('/frontend/images/bottom.svg'); ?>"></span></a>

<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

<script src="<?php echo e(asset("/frontend/js/modernizer.js")); ?>"></script>
<script src="//unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <!-- ALL JS FILES -->
    <script src="<?php echo e(asset("/frontend/js/all.js")); ?>"></script>
    <script src="<?php echo e(asset("/frontend/js/custom.js")); ?>"></script>
    <script src="<?php echo e(asset("/frontend/js/timeline.min.js")); ?>"></script>
    <script src='//cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js'></script>
    <script src='//cdn.jsdelivr.net/jquery.slick/1.6.0/slick.min.js'></script>


<script>
AOS.init({ 
  duration: 1000, 
});
</script>
<script>
$(document).ready(function () {
  $('.testiSlide').slick({
    slidesToShow: 3,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 1500,
    responsive: [{
      breakpoint: 850,
      settings: {
        slidesToShow: 1,
        slidesToScroll: 1,
        infinite: true,
      }
    }]
  });
});
</script>
    <script>
        var i = 0;
        $("body").on('click', '#nextSlide', function () {
            i++;
            if (i == $('.slide').length) {
                $('.slide.active').removeClass('active out');
                $($('.slide')[0]).addClass('active');
                i = 0;
            }
            else {
                $('.slide.active').addClass('out').next('.slide').addClass('active');
            }
        });

        document.addEventListener("DOMContentLoaded", function () {
            document.querySelectorAll('.navbar-nav .nav-link').forEach(function (element) {

                element.addEventListener('click', function (e) {

                    let nextEl = element.nextElementSibling;
                    let parentEl = element.parentElement;

                    if (nextEl) {
                        e.preventDefault();
                        let mycollapse = new bootstrap.Collapse(nextEl);

                        if (nextEl.classList.contains('show')) {
                            mycollapse.hide();
                        } else {
                            mycollapse.show();
                            // find other submenus with class=show
                            var opened_submenu = parentEl.parentElement.querySelector('.submenu.show');
                            // if it exists, then close all of them
                            if (opened_submenu) {
                                new bootstrap.Collapse(opened_submenu);
                            }
                        }
                    }
                }); // addEventListener
            }) // forEach
        });

       
    </script>

<!-- Validation JS -->
<script src="<?php echo e(asset("/frontend/js/jquery.validationEngine.min.js")); ?>"></script>
<script src="<?php echo e(asset("/frontend/js/jquery.validationEngine-en.js")); ?>"></script>
<script>
  function customvalidation()
  {
    jQuery(".customvalidation").validationEngine('attach', {
      relative: true,
      overflownDIV:"#divOverflown",
      promptPosition:"topLeft"
    });
    jQuery(".customvalidation_bottom").validationEngine('attach', {
      relative: true,
      overflownDIV:"#divOverflown",
      promptPosition:"bottomLeft"
    });
  }
  customvalidation();

  var confirmModal = function(){
    $('#deleteModal .modal-body .content').html($(this).attr('data-confirm'));
    $('#deleteModal .title').html($(this).attr('data-title'));
    $('#dataConfirmOK').attr('href',$(this).attr('href'));
    $('#deleteModal').modal('show');
    return false;
  };

  $('body').on('click', 'a[data-confirm]', confirmModal);

</script>

<?php if(Session::has('message')): ?> 
<?php endif; ?>
<script>
  $(document).ready(function() {  
    $("#alertMessage .title").hide();
    $("#alertMessage .content").empty().html('WWWWW<?php echo Session::get('message'); ?>');
    $("#alertMessage").fadeIn();
    // $("#alertMessage").modal('show');
    // setTimeout(function() { $('#alertMessage').fadeOut(); }, <?php echo config('site.message_show_time')*1000; ?>);
  });
</script>


<?php echo $__env->yieldContent('more-scripts'); ?>

</body>
</html><?php /**PATH E:\wamp64\www\webtechnomind\infotree\resources\views/frontend/footer.blade.php ENDPATH**/ ?>