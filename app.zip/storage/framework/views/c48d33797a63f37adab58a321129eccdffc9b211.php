<?php echo e($slot); ?>

<?php /**PATH E:\wamp64\www\webtechnomind\globalization\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>