 
<?php echo $__env->make('frontend.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 
 <div class="inner-page">
        <div class="privacy">
            <div class="container">
                <?php $__currentLoopData = $extra_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

      <?php if($val->type==1 && $val->title): ?>
                <h1><?php echo $val->title; ?></h1>
                 <?php endif; ?>
    
               <?php if($val->type==1 && $val->body): ?>
               <?php echo $val->body; ?>

                 <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
<?php echo $__env->make('frontend.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp\htdocs\dopadoxnw\resources\views/frontend/pages/privacy_policy.blade.php ENDPATH**/ ?>