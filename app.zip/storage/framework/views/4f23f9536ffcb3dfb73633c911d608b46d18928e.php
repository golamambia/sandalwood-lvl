<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?php if(@$setting[0]->value){ echo @$setting[0]->value.' | '.config('site.title') ; }else{ echo config('site.title'); } ?></title>
  <meta name="keywords" content="<?php if(@$setting[1]->value){ echo @$setting[1]->value ; }else{ echo config('site.meta_keyword'); } ?>">
  <meta name="description" content="<?php if(@$setting[2]->value){ echo @$setting[2]->value ; }else{ echo config('site.meta_description'); } ?>">
    <?php if(config('site.logo2') && File::exists(public_path('uploads/'.config('site.logo2')))): ?>
    <link rel="shortcut icon" href="<?php echo ( config('site.logo2') && File::exists(public_path('uploads/'.config('site.logo2'))) ) ? asset('/uploads/'.config('site.logo2')) : ''; ?>" type="image/x-icon" />
    <?php endif; ?>

  <link rel="stylesheet" href="<?php echo e(asset("/frontend/css/bootstrap.min.css")); ?>">
  <link rel="stylesheet" href="<?php echo e(asset("/frontend/style.css")); ?>">
  <link rel="stylesheet" href="<?php echo e(asset("/frontend/css/versions.css")); ?>">
  <link rel="stylesheet" type="text/css" href="<?php echo e(asset("/frontend/css/validationEngine.jquery.min.css")); ?>">
  <link rel="stylesheet" href="<?php echo e(asset("/frontend/css/responsive.css")); ?>">
  <link rel="stylesheet" href="<?php echo e(asset("/frontend/css/custom.css")); ?>">

  <link href="//unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
  <link rel="stylesheet" href="<?php echo e(asset("/frontend/custom-style.css")); ?>">

</head>

<body class="host_version">
<?php
$header_menu = get_fields_value_where('pages',"(display_in='1' or display_in='3') and posttype='page' and parent_id='0'",'menu_order','asc');
$categories = get_fields_value_where('it_category',"status='1'",'rank','asc');
?>

    <header class="top-navbar">
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container">
                <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                    <img src="<?php echo ( config('site.logo') && File::exists(public_path('uploads/'.config('site.logo'))) ) ? asset('/uploads/'.config('site.logo')) : asset('/frontend/images/logo.svg'); ?>" alt="" />
                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbars-host"
                    aria-controls="navbars-rs-food" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbars-host">
                 
                    <ul class="navbar-nav ml-auto">
                        
                      <div class="dropdown">
                          <!-- <a class="language"  id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                           <span><img src="<?php echo asset('/frontend/images/globe.svg'); ?>"></span>   English
                          </a>
                          <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                            <a class="dropdown-item" href="#">French</a>
                            <a class="dropdown-item" href="#">Hindi</a> 
                          </div> -->
                        </div>
                        <?php          
                        $counter = 0;
                        ?>
                        <?php $__currentLoopData = $header_menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                        $counter++;
                        $slug = $menu->slug;
                        if ($menu->menu_link>0) {
                          $slug = get_field_value('pages',"slug",'id',$menu->menu_link);
                        }
                        $active_sub_menu = '';
                        if (@$page) {
                          $active_sub_menu = (@$page && ($page->parent_id==$menu->id || $page->id==$menu->id || $menu->menu_link==$page->id)) ? 'active' : '' ;
                        }
                        ?>
                        <li class="nav-item <?php echo $active_sub_menu; ?>"><a class="nav-link" href="<?php echo e(url('/'.$slug)); ?>"> <?php echo $menu->page_name; ?></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                  <a class="nav-call xs-hidden" ><span><img src="<?php echo asset('/frontend/images/call.svg'); ?>"></span></a>
                   
                </div>
            </div>
        </nav>
    </header>



<?php /**PATH E:\wamp64\www\webtechnomind\infotree\resources\views/frontend/header.blade.php ENDPATH**/ ?>