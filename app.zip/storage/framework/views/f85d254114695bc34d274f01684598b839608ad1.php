
<?php
$service_menu = get_fields_value_where('pages',"(display_in='1' or display_in='3') and posttype='service' and parent_id='0'",'menu_order','asc');

$counter=0;
$total=count($service_menu);
$html = '';
$html_li = '';
$active = '';
foreach ($service_menu as $key => $value) {
  $counter++;
  if ($page->parent_id==$value->id || $page->id==$value->id || $value->menu_link==$value->id) {
    $active_li = 'active';
    $active = 'active';
  }else{
    $active_li = '';
  }
  $slug = $value->slug;
  if ($value->menu_link>0) {
    $slug = get_field_value('pages',"slug",'id',$value->menu_link);
  }
  $html_li .= '<li class="nav-item '.$active_li.'"><a class="nav-link" href="'.url('/'.$slug).'">'.$value->page_name.'</a></li>';
  if ($counter%4==0 || $counter==$total) {
    $html .= '<div class="slide '.$active.'"><ul class="navbar-nav ">'.$html_li.'</ul></div>';
    $active = '';
    $html_li = '';
  }
}

if ($page->parent_id>0) {
  $service_sub_menu = get_fields_value_where('pages',"(display_in='1' or display_in='3') and parent_id='".$page->parent_id."'",'menu_order','asc');
}else{
  $service_sub_menu = get_fields_value_where('pages',"(display_in='1' or display_in='3') and parent_id='".$page->id."'",'menu_order','asc');
}
?>
<div class="bottom-navbar">
  <nav class="navbar navbar-expand-lg navbar-light bg-light">
    <div class="container align-items-center">
      <div id="textSlider">
        <?php echo $html; ?>

      </div>
      <a class="nav-call xs-hidden" id="nextSlide"><span><img src="<?php echo asset('/frontend/images/next.svg'); ?>"></span></a>
    </div>
  </nav>
</div>

<div class="banner-image" style="background-image:url('<?php echo $page->bannerimage && File::exists(public_path('uploads/'.$page->bannerimage))?asset('/uploads/'.$page->bannerimage):asset('/frontend/images/platform-en.jpg'); ?>');">
  <div class="container">
    <div class="banner-title wow fadeIn">
      <h3><?php echo $page->page_title; ?></h3>
    </div>

  </div>
</div>

<?php if($service_sub_menu->count() > 0): ?>
<div class="container">
  <div class="third-navbar">
    <nav class="navbar navbar-expand-lg navbar-light ">

      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbars-third"
      aria-controls="navbars-rs-food" aria-expanded="false" aria-label="Toggle navigation">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbars-third">

        <ul class="navbar-nav m-auto">
          <?php          
          $counter = 0;
          ?>
          <?php $__currentLoopData = $service_sub_menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub_menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php
          $counter++;
          $slug = $sub_menu->slug;
          if ($sub_menu->menu_link>0) {
            $slug = get_field_value('pages',"slug",'id',$sub_menu->menu_link);
          }
          $active_sub_menu = ($page->parent_id==$sub_menu->id || $page->id==$sub_menu->id || $sub_menu->menu_link==$page->id) ? 'active' : '' ;
          ?>
          <li class="nav-item <?php echo $active_sub_menu; ?>"><a class="nav-link" href="<?php echo e(url('/'.$slug)); ?>"> <?php echo $sub_menu->page_name; ?></a></li>
          <?php if($service_sub_menu->count()!=$counter): ?><li class="xs-hidden">|</li><?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>

      </div>
    </nav>
  </div>
</div>
<?php endif; ?>
<?php /**PATH E:\wamp64\www\webtechnomind\infotree\resources\views/frontend/pages/service-top.blade.php ENDPATH**/ ?>