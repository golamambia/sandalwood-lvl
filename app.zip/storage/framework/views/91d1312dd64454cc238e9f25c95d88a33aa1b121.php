<?php echo $__env->make('frontend.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- slider area start -->
<div class="home-slider innerbg">
  <div class="cycle-slideshow home-slideshow"  data-cycle-slides="&gt; div" data-cycle-pager=".home-pager" data-cycle-timeout="5000"  data-cycle-prev="#HomePrev" data-cycle-next="#HomeNext">
    <div class="slide" style="background-image:url(<?php echo $page[0]->bannerimage && File::exists(public_path('uploads/'.$page[0]->bannerimage))?asset('/uploads/'.$page[0]->bannerimage):asset('/frontend/images/inner-bg.jpg'); ?>);">
      <div class="caption">
        <div class="container">
          <div class="con">
            <h4><?php echo e($page[0]->page_title); ?></h4>
            <ul>
              <li><a href="<?php echo e(url('/')); ?>">Home</a> </li>
              <li><?php echo e($page[0]->page_name); ?></li>
            </ul>           
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="home-pager"></div>
</div>
<!-- slider area stop --> 

<div class="somthing">
	<div class="container">
        <?php echo $page[0]->body; ?>

  </div>
</div>
<?php echo $__env->make('frontend.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\webtechnomind\infotree\resources\views/frontend/pages/pages.blade.php ENDPATH**/ ?>