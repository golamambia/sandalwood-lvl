<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PageExtra extends Model
{
    protected $table = 'pages_extra';
	public $timestamps = false;
}
